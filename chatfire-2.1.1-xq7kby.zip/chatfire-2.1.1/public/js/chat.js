let ws = null

$(function () {
    startChat()
})

function startChat () {
  ws = adonis.Ws().connect()

  ws.on('open', () => {
    $('.connection-status').addClass('connected')
    subscribeToChannel()
  })

  ws.on('error', () => {
    $('.connection-status').removeClass('connected')
  })
}

function subscribeToChannel () {
  const chat = ws.subscribe('chat')

  chat.on('error', () => {
    $('.connection-status').removeClass('connected')
  })

  chat.on('message', (chat) => {
    let isme = chat.from_me ? 'me' : '';
    let tick = chat.from_me ? '<span><i class="fa fa-check"></i></span>' : '';
    $('.needremove').remove();
    console.log(chat)
    // let message = chat.message.message.extendedTextMessage ? chat.message.message.extendedTextMessage.text : chat.message.message.conversation;
    if(chat.type == "image"){
      $('.card-body[data-device="'+chat.device+'"][data-id="'+chat.id+'"] .messages').append(`
        <div class="chat-item ${isme}" data-wid="${chat.wa_id}"><div class="chat-bubble"><img src="${base_url}${chat.media_url}" onerror="this.src='https://www.publicdomainpictures.net/pictures/280000/velka/not-found-image-15383864787lu.jpg';"><p class="caption">${chat.message}</p></div><time class="timeago" datetime="${ new Date(chat.timestamp * 1000).toISOString()}">${ new Date(chat.timestamp * 1000).toISOString()}</time>${tick}</div>
      `)
      $('.contact-container tr[data-device="'+chat.device+'"][data-id="'+chat.id+'"] p').html('<i class="ni ni-image"></i>Photo');
    }else if(chat.type == "video"){
      $('.card-body[data-device="'+chat.device+'"][data-id="'+chat.id+'"] .messages').append(`
        <div class="chat-item ${isme}" data-wid="${chat.wa_id}"><div class="chat-bubble">
                          <video loop autoplay muted poster="${base_url}${chat.media_url}">
                            <source src="${base_url}${chat.media_url}" type="video/mp4">
                            Your browser does not support the video tag.
                          </video><p class="caption">${chat.message}</p></div><time class="timeago" datetime="${ new Date(chat.timestamp * 1000).toISOString()}">${ new Date(chat.timestamp * 1000).toISOString()}</time>${tick}</div>
      `)
      $('.contact-container tr[data-device="'+chat.device+'"][data-id="'+chat.id+'"] p').html('<i class="ni ni-image"></i>Video');
    }else if(chat.type == "document"){
      $('.card-body[data-device="'+chat.device+'"][data-id="'+chat.id+'"] .messages').append(`
        <div class="chat-item ${isme}" data-wid="${chat.wa_id}"><div class="chat-bubble"><a href="${base_url}${chat.media_url}" target="_blank">
                            <i class="ni ni-paper-diploma"></i> ${chat.message}
                          </a></div><time class="timeago" datetime="${ new Date(chat.timestamp * 1000).toISOString()}">${ new Date(chat.timestamp * 1000).toISOString()}</time>${tick}</div>
      `)
      $('.contact-container tr[data-device="'+chat.device+'"][data-id="'+chat.id+'"] p').html('<i class="ni ni-paper-diploma"></i>Document');
    }else{
      $('.card-body[data-device="'+chat.device+'"][data-id="'+chat.id+'"] .messages').append(`
        <div class="chat-item ${isme}" data-wid="${chat.wa_id}"><div class="chat-bubble">${chat.message}</div><time class="timeago" datetime="${ new Date(chat.timestamp * 1000).toISOString()}">${ new Date(chat.timestamp * 1000).toISOString()}</time>${tick}</div>
      `)
      $('.contact-container tr[data-device="'+chat.device+'"][data-id="'+chat.id+'"] p').html(chat.message);
    }
    var d = new Date();
    let h = d.getHours();
    let i = d.getMinutes();
    $('.contact-container tr[data-device="'+chat.device+'"][data-id="'+chat.id+'"] .media-body .time').html(h+":"+i);
    if($(".chat-container").length){
      $(".chat-container").stop().animate({ scrollTop: $(".chat-container")[0].scrollHeight}, 100);
    }
    $('.card-body[data-id="'+chat.id+'"] .typing').remove();
    $('.contact-container tr[data-device="'+chat.device+'"][data-id="'+chat.id+'"]').prependTo(".contact-container tbody");
    $("time.timeago").timeago()

    let unread = $('.contact-container tr[data-device="'+chat.device+'"][data-id="'+chat.id+'"] .unread');
    let total  = parseInt(unread.html());
    if(!chat.from_me){
      unread.html(total+1);
      unread.show();
      let notif = $( '.contact-container [data-device="'+chat.device+'"] .unread' ).length ? 0 : parseInt($('.device[data-device="'+chat.device+'"] .device-unread').html());
      let totalnotif = 0;
      console.log("exist",$( '.contact-container [data-device="'+chat.device+'"] .unread' ).length);
      if($( '.contact-container [data-device="'+chat.device+'"] .unread' ).length){
        $( '[data-device="'+chat.device+'"] .unread' ).each(function( index ) {
            notif = notif + parseInt($(this).html());
        });
      }else{
        notif = notif+1;
      }
      console.log("NOTIF ",notif)
      $('.device[data-device="'+chat.device+'"] .device-unread').html(notif);

      $( '.device' ).each(function( index ) {
          totalnotif = totalnotif + parseInt($(this).find('.device-unread').html());
      });
      action("(" + totalnotif + ") New Messages ! ");
      var audio = new Audio(base_url+'/notification/notif.mp3');
      //audio.play();
    }
  })
  chat.on('contact', (presence) => {
    if(presence.type == 'composing'){
      console.log(presence);
      $('.card-body[data-id="'+presence.id+'"] .messages').append(`
          <div class="chat-item typing">
            <div class="chat-bubble">
              <div class="ticontainer">
                <div class="tiblock">
                  <div class="tidot"></div>
                  <div class="tidot"></div>
                  <div class="tidot"></div>
                </div>
              </div>
            </div>
          </div>
      `)
      $(".chat-container").stop().animate({ scrollTop: $(".chat-container")[0].scrollHeight}, 100);
    }else{
      $('.card-body[data-id="'+presence.id+'"] .typing').remove();
    }
  })

  chat.on('status', (presence) => {
    console.log("presence status", presence.wa_ids)
    presence.wa_ids.forEach((entry) => {
      if(presence.status == "DELIVERED"){
        $('.chat-item[data-wid="' + entry + '"] span').html('<i class="fa fa-check"></i><i class="fa fa-check"></i>');
        $('.chat-item[data-wid="' + entry + '"] time.timeago').css('margin-right','25px')
      }else if(presence.status == "READ"){
        $('.chat-item[data-wid="' + entry + '"] time.timeago').css('margin-right','25px')
        $('.chat-item[data-wid="' + entry + '"] span').html('<i class="fa fa-check blue"></i><i class="fa fa-check blue"></i>');
      }
    })
  })
}
$('#message').keyup(function (e) {
  if (e.which === 13) {
    e.preventDefault()
    $('#icon').removeClass('show')
    const message = $(this).val()
    var output = document.getElementById('file').files[0]
    $(this).val('')
    if(output){
      if( output.name.split('.').pop() == 'mp4'){
        let preview = URL.createObjectURL(output);
        $('.card-body .messages').append(`
            <div class="chat-item me needremove"><div class="chat-bubble"><video id="video-preview" loop autoplay muted src="${preview}"></video><p class="caption">${message}</p></div><time class="timeago" datetime="${ new Date().toISOString()}">${ new Date().toISOString()}</time><span><i class="fa fa-clock"></i></span></div>
        `)
      }else if( output.name.split('.').pop() == 'pdf'){
        let preview = URL.createObjectURL(output);
        $('.card-body .messages').append(`
            <div class="chat-item me needremove"><div class="chat-bubble"><a href="#"><i class="ni ni-paper-diploma"></i> ${output.name}</a></div><time class="timeago" datetime="${ new Date().toISOString()}">${ new Date().toISOString()}</time><span><i class="fa fa-clock"></i></span></div>
        `)
      }else{
        let preview = URL.createObjectURL(output);
        console.log(preview)
        $('.card-body .messages').append(`
            <div class="chat-item me needremove"><div class="chat-bubble"><img src="${preview}" onerror="onimageerror(this)"><p class="caption">${message}</p></div><time class="timeago" datetime="${ new Date().toISOString()}">${ new Date().toISOString()}</time><span><i class="fa fa-clock"></i></span></div>
        `)
      }
    }else{
      $('.card-body .messages').append(`
          <div class="chat-item me needremove"><div class="chat-bubble">${message}</div><time class="timeago" datetime="${ new Date().toISOString()}">${ new Date().toISOString()}</time><span><i class="fa fa-clock"></i></span></div>
      `)
    }
    $("time.timeago").timeago()
    $(".chat-container").stop().animate({ scrollTop: $(".chat-container")[0].scrollHeight}, 100);
    ws.getSubscription('chat').emit('message', {
      username: window.username,
      body: message
    })
    return
  }
})

$('.icon-button').click(function(){
  $('#icon').toggleClass('show')
})

$('.itemot').click(function(){
  let emoticon = $('input[name="message"]').val()
  let icon = emoticon + $(this).html()
  $('input[name="message"]').val(icon)
})
function action(txt) {
  var speed=300;
  var refresh=null; 
  document.title=txt;
  txt=txt.substring(1,txt.length)+txt.charAt(0);
  refresh=setTimeout(function(){ action(txt); }, speed);
}