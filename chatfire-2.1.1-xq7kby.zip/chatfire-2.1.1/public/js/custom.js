jQuery(document).ready(function() {
  $( "time.timeago" ).each(function( index ) {
    if($('.me > span i').length > 1){
      $( this ).css('margin-right','25px')
    }
    console.log( index + ": " + $( this ).text() );
    let time = jQuery( this ).attr('datetime');
    var s = new Date(time*1000).toISOString();
    jQuery( this ).attr('datetime', s)
    jQuery( this ).html(s)
  });
  jQuery("time.timeago").timeago()
});