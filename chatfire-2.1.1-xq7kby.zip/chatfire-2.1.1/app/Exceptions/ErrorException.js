'use strict'

const { LogicalException } = require('@adonisjs/generic-exceptions')

const AUTH_ERROR = {
  'auth/permission-denied': {
    status: 403,
    code: 'E_AUTH_PERMISSION_DENIED',
    message: 'Permission denied.'
  }
}

const DEVICE_ERROR = {
  'device/key-required': {
    status: 401,
    code: 'E_DEVICE_KEY_REQUIRED',
    message: 'device key is required'
  },
  'device/key-invalid': {
    status: 401,
    code: 'E_DEVICE_KEY_INVALID',
    message: 'invalid device key'
  },
  'device/already-pairing': {
    status: 400,
    code: 'E_DEVICE_ALREADY_PAIRING',
    message: 'device already pairing'
  },
  'device/must-paired': {
    status: 400,
    code: 'E_DEVICE_MUST_PAIRED',
    message: 'device must be paired, please pair first!'
  },
  'device/not-found': {
    status: 404,
    code: 'E_DEVICE_NOT_FOUND',
    message: 'device not found'
  }
}

const PHONE_ERROR = {
  'phone/not-registered': {
    status: 400,
    code: 'E_PHONE_NOT_REGISTERED',
    message: 'phone not registered on whatsapp'
  }
}

const GROUP_ERROR = {
  'group/create-failed': {
    status: 400,
    code: 'E_GROUP_CREATE_FAILED',
    message: 'Failed to create group'
  }
}

const CHAT_ERROR = {
  'chat/not-found': {
    status: 404,
    code: 'E_CHAT_NOT_FOUND',
    message: 'chat not found'
  },
  'chat/clear-failed': {
    status: 400,
    code: 'E_CHAT_CLEAR_FAILED',
    message: 'failed to clear chat'
  }
}

const errors = {
  ...AUTH_ERROR,
  ...DEVICE_ERROR,
  ...PHONE_ERROR,
  ...GROUP_ERROR,
  ...CHAT_ERROR,
  default: {
    status: 500,
    code: 'E_INTERNAL_SERVER_ERROR',
    message: 'ups, something when wrong!'
  }
}

class ErrorException extends LogicalException {
  constructor(errorKey) {
    const { message, status, code } = Object.keys(errors).includes(errorKey) ? errors[errorKey] : errors.default
    super(message, status, code)
  }
}

module.exports = ErrorException
