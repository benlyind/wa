'use strict'

const BaseExceptionHandler = use('BaseExceptionHandler')

/**
 * This class handles all exceptions thrown during
 * the HTTP request lifecycle.
 *
 * @class ExceptionHandler
 */
class ExceptionHandler extends BaseExceptionHandler {
  /**
   * Handle exception thrown during the HTTP lifecycle
   *
   * @method handle
   *
   * @param  {Object} error
   * @param  {Object} options.request
   * @param  {Object} options.response
   *
   * @return {void}
   */
  async handle(error, { request, response }) {
    error.message = error.message.split(': ')[1]

    switch (error.code) {
      case 'E_MISSING_DATABASE_ROW':
        error.code = 'E_NOT_FOUND'
        error.message = 'Not found'
        break
    }

    response.status(error.status).send({
      status: error.status,
      code: error.code,
      message: error.message
    })
  }

  /**
   * Report exception for logging or debugging.
   *
   * @method report
   *
   * @param  {Object} error
   * @param  {Object} options.request
   *
   * @return {void}
   */
  async report() { }
}

module.exports = ExceptionHandler
