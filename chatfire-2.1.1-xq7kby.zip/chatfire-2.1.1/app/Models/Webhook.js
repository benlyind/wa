'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class Webhook extends Model {
  static get Serializer() {
    return 'App/Models/Serializer'
  }

  static get visible() {
    return ['url', 'headers']
  }

  getHeaders(headers) {
    if (headers === null) return {}
    if (typeof headers === 'string') return JSON.parse(headers)
    return headers
  }

  device() {
    return this.belongsTo('App/Models/Device')
  }

  events() {
    return this.hasMany('App/Models/WebhookEvent')
  }
}

module.exports = Webhook
