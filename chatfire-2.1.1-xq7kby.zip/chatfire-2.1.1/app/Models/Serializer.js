const VanillaSerializer = require('@adonisjs/lucid/src/Lucid/Serializers/Vanilla')
const _ = require('lodash')

class Serializer extends VanillaSerializer {
  toJSON() {
    if (this.isOne) {
      return this._getRowJSON(this.rows)
    }

    const data = this.rows.map(this._getRowJSON.bind(this))
    if (this.pages) {
      return _.merge({}, this.formatPages(this.pages), { data })
    }
    return data
  }

  formatPages({ total, perPage, page, lastPage }) {
    return {
      total: Number(total),
      per_page: perPage,
      page,
      last_page: lastPage
    }
  }
}

module.exports = Serializer
