'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')
const Event = use('Event')

class Setting extends Model {
  static boot() {
    super.boot()

    this.addHook('afterUpdate', async (instance) => {
      const device = await instance.device().fetch()
      if (device.status === 'PAIRED') {
        Event.fire('reconnect::device', { id: device.id, auth: device.auth })
      }
    })
  }

  static get visible() {
    return ['auto_read', 'auto_save_media', 'include_group_message', 'sync_story', 'sync_contact', 'auto_takeover', 'auto_takeover_delay']
  }

  static get hidden() {
    return ['id', 'device_id', 'created_at']
  }

  static scopeByDevice(query, device_id) {
    return query.where({ device_id })
  }

  device() {
    return this.belongsTo('App/Models/Device')
  }
}

module.exports = Setting
