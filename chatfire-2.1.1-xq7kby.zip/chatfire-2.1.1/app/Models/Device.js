'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')
const uuid = require('uuid')

class Device extends Model {
  static get Serializer() {
    return 'App/Models/Serializer'
  }

  static boot() {
    super.boot()

    this.addHook('beforeCreate', async (instance) => {
      instance.device_key = uuid.v4()
    })

    this.addHook('afterCreate', async (instance) => {
      await instance.webhook().create({ url: '' })
      await instance.setting().create({})
    })
  }

  static get hidden() {
    return ['owner_id', 'auth', 'qr_code']
  }

  static scopeByOwner(query, owner_id) {
    return query.where({ owner_id })
  }

  getRunning(running) {
    return Boolean(running)
  }

  getPaired(paired) {
    return Boolean(paired)
  }

  owner() {
    return this.belongsTo('App/Models/User')
  }

  messages() {
    return this.hasMany('App/Models/Message')
  }

  webhook() {
    return this.hasOne('App/Models/Webhook')
  }

  contacts() {
    return this.hasMany('App/Models/Contact')
  }

  setting() {
    return this.hasOne('App/Models/Setting')
  }
}

module.exports = Device
