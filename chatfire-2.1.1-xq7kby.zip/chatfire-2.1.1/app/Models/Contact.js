'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class Contact extends Model {
  static get Serializer() {
    return 'App/Models/Serializer'
  }

  static get visible() {
    return ['id', 'name', 'phone']
  }

  static scopeByDevice(query, device_id) {
    return query.where({ device_id })
  }

  device() {
    return this.belongsTo('App/Models/Device')
  }
}

module.exports = Contact
