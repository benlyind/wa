'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class Group extends Model {
  static get Serializer() {
    return 'App/Models/Serializer'
  }

  static get hidden() {
    return ['device_id']
  }

  static scopeByDevice(query, device_id) {
    return query.where({ device_id })
  }

  getParticipants(participants) {
    if (participants === null) return []
    if (typeof participants === 'string') return JSON.parse(participants)
    return participants
  }

  device() {
    return this.belongsTo('App/Models/Device')
  }
}

module.exports = Group
