'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class Agent extends Model {
  static get Serializer() {
    return 'App/Models/Serializer'
  }

  static get hidden() {
    return []
  }

  static scopeByKeyword(query, keyword) {
    return query.where({ keyword })
  }


  device() {
    return this.belongsTo('App/Models/Device')
  }
}

module.exports = Agent