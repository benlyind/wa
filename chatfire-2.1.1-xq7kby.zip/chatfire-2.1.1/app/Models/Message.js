'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')
const storyFields = ['id', 'from', 'message', 'media_url', 'type', 'read', 'created_at']

class Message extends Model {
  static get Serializer() {
    return 'App/Models/Serializer'
  }

  static get hidden() {
    return ['wa_id', 'device_id', 'from_story', 'read']
  }

  static get computed() {
    return ['read']
  }

  static boot() {
    super.boot()

    this.addHook('afterCreate', async (instance) => {
      const device = await instance.device().fetch()
      if (instance.from_me) {
        instance.from = device.phone
      } else {
        instance.to = device.phone
      }

      await instance.save()
    })
  }

  static scopeByDevice(query, device_id) {
    return query.where({ device_id })
  }

  static scopeExcludeGroup(query) {
    return query.where({ from_group: false })
  }

  static scopeOnlyStory(query) {
    return query
      .where({ from_story: true })
      .setVisible(storyFields)
  }

  static scopeExcludeStory(query) {
    return query.where({ from_story: false })
  }

  getFromMe(fromMe) {
    return Boolean(fromMe)
  }

  getFromGroup(fromGroup) {
    return Boolean(fromGroup)
  }

  getFromStory(fromStory) {
    return Boolean(fromStory)
  }

  getRead({ status }) {
    return Boolean(status === 'READ')
  }

  getTimestamp(timestamp) {
    return parseInt(timestamp)
  }

  device() {
    return this.belongsTo('App/Models/Device')
  }
}

module.exports = Message
