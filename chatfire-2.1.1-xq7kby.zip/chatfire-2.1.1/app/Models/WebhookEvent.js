'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')
const Notification = use('Notification')

class WebhookEvent extends Model {
  static get Serializer() {
    return 'App/Models/Serializer'
  }

  static boot() {
    super.boot()

    this.addHook('afterCreate', async (instance) => {
      const webhook = await instance.webhook().fetch()
      if (webhook && webhook.url) {
        Notification.send(webhook, instance)
      }
    })
  }

  getProcessed(processed) {
    return Boolean(processed)
  }

  getData(data) {
    if (data === null) return {}
    if (typeof data === 'string') return JSON.parse(data)
    return data
  }

  setData(data) {
    if (typeof data === 'object') data = JSON.stringify(data)
    return data
  }

  webhook() {
    return this.belongsTo('App/Models/Webhook')
  }
}

module.exports = WebhookEvent
