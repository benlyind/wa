'use strict'
/** @typedef {import('@adonisjs/framework/src/Request')} Request */
/** @typedef {import('@adonisjs/framework/src/Response')} Response */
/** @typedef {import('@adonisjs/framework/src/View')} View */

const Device = use('App/Models/Device')
const Error = use('Error')

class OwnDevice {
  /**
   * @param {object} ctx
   * @param {Request} ctx.request
   * @param {Function} next
   */
  async handle({ params, auth, request }, next) {
    const device = await Device
      .query()
      .byOwner(auth.user.id)
      .where({ id: params.id })
      .with('webhook')
      .first()

    if (!device) throw new Error('device/not-found')
    request.device = device
    await next()
  }
}

module.exports = OwnDevice
