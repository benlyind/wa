'use strict'
/** @typedef {import('@adonisjs/framework/src/Request')} Request */
/** @typedef {import('@adonisjs/framework/src/Response')} Response */
/** @typedef {import('@adonisjs/framework/src/View')} View */

const Device = use('App/Models/Device')
const Config = use('Config')
const DeviceStatus = Config.get('device.status')
const Error = use('Error')

class DeviceMustBePaired {
  /**
   * @param {object} ctx
   * @param {Request} ctx.request
   * @param {Function} next
   */
  async handle({ request }, next) {
    const device = await Device.find(request.device_id)

    if (device.status !== DeviceStatus.PAIRED) {
      throw new Error('device/must-paired')
    }
    await next()
  }
}

module.exports = DeviceMustBePaired
