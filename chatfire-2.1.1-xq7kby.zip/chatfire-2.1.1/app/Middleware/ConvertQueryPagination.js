'use strict'

const _ = require('lodash')

class ConvertQueryPagination {
  async handle({ request }, next) {
    const query = request.get()
    const page = _.isNumber(query.page) ? query.page : _.toNumber(query.page) || 1
    const limit = _.isNumber(query.limit) ? query.limit : _.toNumber(query.limit) || 20
    const sort_by = (allowedFields = []) => allowedFields.includes(query.sort_by) ? query.sort_by : 'id'
    const order_by = ['asc', 'desc'].includes(query.order_by) ? query.order_by : 'asc'

    request.query = { ...query, page, limit, sort_by, order_by }

    await next()
  }
}

module.exports = ConvertQueryPagination
