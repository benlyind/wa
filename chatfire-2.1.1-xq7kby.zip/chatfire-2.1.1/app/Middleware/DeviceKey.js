'use strict'
/** @typedef {import('@adonisjs/framework/src/Request')} Request */
/** @typedef {import('@adonisjs/framework/src/Response')} Response */
/** @typedef {import('@adonisjs/framework/src/View')} View */

const Device = use('App/Models/Device')
const Error = use('Error')

class DeviceKey {
  /**
   * @param {object} ctx
   * @param {Request} ctx.request
   * @param {Function} next
   */
  async handle({ request }, next) {
    const device_key = request.header('device-key', null)
    if (!device_key) {
      throw new Error('device/key-required')
    }

    const device = await Device.findBy({ device_key })
    if (!device) {
      throw new Error('device/key-invalid')
    }

    request.device_id = device.id

    await next()
  }
}

module.exports = DeviceKey
