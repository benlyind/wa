'use strict'

const Listener = module.exports = {}
const Chatfire = use('Chatfire')
const Notification = use('Notification')

async function notifyMissedCall(type, data) {
  const { key: { remoteJid: jid }, messageTimestamp } = data.message

  await Notification.send(data.id, {
    event: `${type}:missed-call`,
    data: {
      from: Chatfire.rejid(jid),
      timestamp: typeof messageTimestamp === 'object' ? messageTimestamp.low : messageTimestamp
    }
  })
}

Listener.voice = async (data) => {
  await notifyMissedCall('voice', data)
}

Listener.video = async (data) => {
  await notifyMissedCall('video', data)
}
