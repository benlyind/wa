'use strict'

const Utils = module.exports = {}
const Group = use('App/Models/Group')
const Chatfire = use('Chatfire')

Utils.save = async (device_id, data) => {
  const group = await Group.findOrCreate(
    { id: data.id, device_id },
    { id: data.id, device_id }
  )

  group.merge({ ...data, participants: JSON.stringify(data.participants) })
  await group.save()
}

Utils.remove = async (device_id, group_ids) => {
  await Group
    .query()
    .where('device_id', device_id)
    .whereNotIn('id', group_ids)
    .delete()
}

Utils.formatGroup = ({ id: gid, subject, owner, participants }) => {
  return {
    id: Chatfire.rejid(gid),
    name: subject,
    owner: Chatfire.rejid(owner),
    participants: participants.map(p => Utils.formatParticipant(p))
  }
}

Utils.formatParticipant = ({ id, isAdmin }) => {
  return { id: Chatfire.rejid(id), is_admin: isAdmin }
}
