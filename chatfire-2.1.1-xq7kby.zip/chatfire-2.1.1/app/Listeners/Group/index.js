'use strict'
const Listener = module.exports = {}
const Chatfire = use('Chatfire')
const { formatGroup, save, remove } = require('./utils')

Listener.sync = async ({ id }) => {
  try {
    const wa = await Chatfire.pick(id)
    const groups = await Chatfire.groups(wa)
    groups.map(async ({ jid }) => {
      Listener.update({ id, update: { jid } })
    })

    const ids = groups.map(({ jid }) => Chatfire.rejid(jid))
    remove(id, ids)
  } catch (_) { }
}

Listener.update = async ({ id, update: { jid } }) => {
  try {
    const wa = await Chatfire.pick(id)
    const meta = await Chatfire.group(wa, jid)
    const group = formatGroup(meta)

    await save(id, group)
  } catch (error) {
    if (error.status === 401) {
      await remove(id, [Chatfire.rejid(jid)])
    }
  }
}
