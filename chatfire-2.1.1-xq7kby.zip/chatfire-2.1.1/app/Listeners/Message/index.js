'use strict'

const Listener = module.exports = {}
const Chatfire = use('Chatfire')
const Setting = use('App/Models/Setting')
const Message = use('App/Models/Message')
const Text = require('./Text')
const Media = require('./Media')
const Status = require('./Status')
const { AckStatus, formatType, TEXT_TYPES, MEDIA_TYPES, getFileType } = require('./Utils')
const { MessageType, WA_MESSAGE_STUB_TYPES } = require('@adiwajshing/baileys')
const Ws = use("Ws");

Listener.receive = receive
Listener.send = send
Listener.status = status
Listener.unread = unread

async function unread({ id }) {
  try {
    const wa = await Chatfire.pick(id)
    const unreads = await wa.loadAllUnreadMessages()
    unreads.map(async (unread) => {
      await receive({ id, message: unread })
    })
  } catch (_) { }
}

async function receive({ id, message }) {
  if ((WA_MESSAGE_STUB_TYPES[message.messageStubType] !== 'UNKNOWN') || !message.message) return
  const setting = await Setting.query().byDevice(id).first()
  const { key, message: content, status, messageTimestamp } = message
  const { remoteJid: jid, fromMe: from_me, id: wa_id, participant } = key
  if (!content) return
  const type = Object.keys(content)[0]
  const from_group = Chatfire.isGroup(jid)
  const from_story = Chatfire.isStory(jid)
  const timestamp = typeof messageTimestamp === 'object' ? messageTimestamp.low : messageTimestamp
  const context = content[type].contextInfo
  const reply_for = context && 'stanzaId' in context ? context.stanzaId : null

  const data = {
    wa_id,
    from_me,
    from_group,
    from_story,
    message: type == 'documentMessage' ? content[type].fileName : '',
    status: from_me ? AckStatus[status === 0 ? 1 : status] : AckStatus[3],
    type: formatType(type),
    timestamp: String(timestamp)
  }

  const rejid = Chatfire.rejid(from_story ? participant : jid)
  if (from_me) {
    data.to = rejid
  } else {
    data.from = rejid
  }

  if (!setting.include_group_message && data.from_group) return
  if (!setting.sync_story && data.from_story) return
  // if (setting.auto_read) {
  //   try {
  //     const wa = await Chatfire.pick(id)
  //     await wa.chatRead(jid)
  //     data.status = AckStatus[4]
  //   } catch (error) { }
  // }

  if (reply_for) {
    const quoted = await Message.query().where({ wa_id: reply_for }).first()
    if (quoted) {
      data.reply_for = quoted.id
    }
  }

  if (TEXT_TYPES.includes(type)) {
    data.message = type === MessageType.text ? content[type] : content[type].text
    await Text.save({ id, data })
  }

  if (MEDIA_TYPES.includes(type)) {
    if(type != 'documentMessage'){
      data.message = content[type].caption || content[type].title || ''
    }

    if (setting.auto_save_media) {
      try {
        const wa = await Chatfire.pick(id)
        data.media_buffer = await wa.downloadMediaMessage(message)
        const { ext } = await getFileType(data.media_buffer)
        data.media_path = `${id}/${wa_id}.${ext}`
      } catch (error) { 
        console.log(error)
      }
    }
    const channel = Ws.getChannel('chat').topic('chat');
    if(channel){
      channel.socket.broadcastToAll("message", data);
    }
    await Media.save({ id, data })
  }
}

async function send({ id, data, quoted }) {
  const wa = await Chatfire.pick(id)
  let jid  = Chatfire.jid(data.to);
  let name = wa.chats.get(jid).name
  data.message = data.message.replace('[nama]',name);
  if (data.type !== 'text') {
    await Media.send({ id, data, quoted })
  } else {
    await Text.send({ id, data, quoted })
  }
}

async function status({ id, status }) {
  const data = {
    wa_ids: status.ids,
    status: AckStatus[status.type]
  }
  const channel = Ws.getChannel('chat').topic('chat');
  channel.socket.broadcastToAll("status", data);

  await Status.save({ id, data })
}
