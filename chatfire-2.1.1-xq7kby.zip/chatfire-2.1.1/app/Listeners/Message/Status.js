'use strict'

const Status = module.exports = {}
const Message = use('App/Models/Message')
const Notification = use('Notification')

Status.save = async ({ id, data }) => {
  await Message
    .query()
    .whereIn('wa_id', data.wa_ids)
    .update({ status: data.status })

  let messages = await Message
    .query()
    .whereIn('wa_id', data.wa_ids)
    .fetch()

  messages = messages.toJSON()
  if (messages.length <= 0) return
  messages = messages.map(({ id, to, from, status, updated_at }) => ({
    id,
    to,
    from,
    status,
    updated_at
  }))

  await Notification.send(id, {
    event: 'updated-status::message',
    data: messages
  })
}
