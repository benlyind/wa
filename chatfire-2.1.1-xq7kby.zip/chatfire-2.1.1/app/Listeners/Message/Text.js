'use strict'

const Text = module.exports = {}
const Message = use('App/Models/Message')
const Chatfire = use('Chatfire')
const { update } = require('./Utils')
const { MessageType } = require('@adiwajshing/baileys')
const Notification = use('Notification')
const Logger = use('Logger')
const Event = use('Event')
const AutoReply = use('App/Models/AutoReply')
const Device = use('App/Models/Device')
const Ws = use("Ws");

Text.save = async ({ id, data }) => {
  let duplicate;
  let message;
  //if(/\p{Extended_Pictographic}/u.test(data.message) == false){
  try{
    message = await Message.findOrNew(
      { wa_id: data.wa_id, device_id: id },
      { wa_id: data.wa_id, device_id: id }
    )
    duplicate = message.$persisted
    message.merge(data)
    await message.save()

    //began of auto reply
    let ar = await AutoReply.findBy('keyword', data.message);
    if(ar){
      let to = data.from;
      let msg = ar.message;
      let reply_for = null;
      let quoted
      const newMessage = {
        device_id:id,
        to,
        message: msg,
        type: 'text',
        from_me: true,
        from_group: false,
        reply_for
      }
      Event.fire('send::message', { id: id, data: newMessage, quoted })
    }
  //}
  } catch (error) {
    console.log(error)
  }
  try {
    const device = await Device.find(id)
    data.device = device.device_key;
    data.id = data.from_me ? data.to : data.from;
    const channel = Ws.getChannel('chat').topic('chat');
    channel.socket.broadcastToAll("message", data);
  } catch (error) {
  }
  if (data.from_me || duplicate) return
  const entity = data.from_story ? 'story' : 'message'

  await Notification.send(id, {
    event: `received::${entity}`,
    data: message
  })
}

Text.send = async ({ id, data, quoted }) => {
  const to = Chatfire.jid(data.to)

  try {
    const wa = await Chatfire.pick(id)
    const valid = await Chatfire.verify(id, to)
    if (!valid) {
      return update(data, { status: 'FAILED' }, 'phone-not-registered')
    }

    const options = {}
    if (quoted) {
      quoted = await wa.loadMessage(to, quoted.wa_id)
      if (quoted) {
        options.quoted = quoted
      }
    }

    wa.sendMessage(to, data.message, MessageType.text, options)
      .then(message => {
        try {
          update(data, { wa_id: message.key.id })
        } catch (error) { console.log(error) }
      }).catch(error => {
        update(data, { status: 'FAILED' }, `cannot send text : ${error.message}`)
      })
  } catch (error) {
    if (error.message === 'not-authorized') {
      return update(data, { status: 'FAILED' }, 'device-not-paired')
    }

    return update(data, { status: 'FAILED' }, 'unknown')
  }
}
