'use strict'

const Media = module.exports = {}
const Message = use('App/Models/Message')
const Drive = use('Drive')
const Chatfire = use('Chatfire')
const Notification = use('Notification')
const { update, getFileType } = require('./Utils')
const { MessageType } = require('@adiwajshing/baileys')
const Device = use('App/Models/Device')
const Ws = use("Ws");

Media.save = async ({ id, data }) => {
  if (data.media_buffer) {
    try {
      const saved = await Drive.put(data.media_path, data.media_buffer)
      if (saved) data.media_url = `/media/${data.media_path}`
    } catch (error) {
      console.log(`cannot save media [device::${id}] cause : ${error.message}`)
    } finally {
      delete data.media_path
      delete data.media_buffer
    }
  }

  const message = await Message.findOrNew(
    { wa_id: data.wa_id, device_id: id },
    { wa_id: data.wa_id, device_id: id }
  )
  const duplicate = message.$persisted
  message.merge(data)
  await message.save()

  try {
    const device = await Device.find(id)
    data.device = device.device_key;
    data.id = data.from_me ? data.to : data.from;
    const channel = Ws.getChannel('chat').topic('chat');
    if(channel){
      channel.socket.broadcastToAll("message", data);
    }
  } catch (error) {
    console.log(error)
  }

  if (data.from_me || duplicate) return
  const entity = data.from_story ? 'story' : 'message'
  await Notification.send(id, {
    event: `received::${entity}`,
    data: message
  })
}

Media.send = async ({ id, data, quoted }) => {
  const to = Chatfire.jid(data.to)
  try {
    const wa = await Chatfire.pick(id)
    const valid = await Chatfire.verify(id, to)

    if (!valid) {
      return update(data, { status: 'FAILED' }, 'phone-not-registered')
    }

    const options = { caption: data.message }
    if (quoted) {
      quoted = await wa.loadMessage(to, quoted.wa_id)
      if (quoted) {
        options.quoted = quoted
      }
    }

    if (data.type === 'document') {
      try {
        const { ext, mime } = await getFileType(data.media_url)
        options.mimetype = mime
        options.filename = `${options.caption}.${ext}`
        delete options.caption
      } catch (_) {
        return update(data, { status: 'FAILED' }, 'cannot-get-mime-type')
      }
    }

    wa.sendMessage(
      to,
      { url: data.media_url },
      MessageType[data.type],
      options
    ).then(message => {
      update(data, { wa_id: message.key.id })
    }).catch(error => {
      update(data, { status: 'FAILED' }, `cannot send media : ${error.message}`)
    })
  } catch (error) {
    if (error.message === 'not-authorized') {
      return update(data, { status: 'FAILED' }, 'device-not-paired')
    }

    return update(data, { status: 'FAILED' }, 'unknown')
  }
}
