'use strict'

const Utils = module.exports = {}
const { MessageType } = require('@adiwajshing/baileys')
const fileType = require('file-type')
const Notification = use('Notification')
const got = require('got')
const mimetypes = require('mime-types')

Utils.AckStatus = {
  0: 'FAILED',
  1: 'PENDING',
  2: 'SENT',
  3: 'DELIVERED',
  4: 'READ',
  5: 'PLAYED'
}

Utils.TEXT_TYPES = [
  MessageType.text,
  MessageType.extendedText
]

Utils.MEDIA_TYPES = [
  MessageType.audio,
  MessageType.image,
  MessageType.video,
  MessageType.document
]

Utils.formatType = (type) => {
  return type
    .replace('conversation', 'text')
    .replace('extendedText', 'text')
    .replace('Message', '')
}

Utils.getFileType = async (file) => {
  let mime
  const isBuffer = Buffer.isBuffer(file)

  if (isBuffer) {
    mime = (await fileType.fromBuffer(file)).mime
  } else {
    const res = await got(file)
    if (res.statusCode === 200) {
      mime = res.headers['content-type']
      if (!mime) {
        const buffer = await res.buffer()
        mime = (await fileType.fromBuffer(buffer)).mime
      }
    }
  }

  const ext = mimetypes.extension(mime)

  if (mime && ext) {
    return { ext, mime }
  }

  throw new Error('cannot-get-file-type')
}

Utils.update = async (data, newData, reason = null) => {
  try {
  data.merge({ ...newData, failed_reason: reason })
  await data.save()
  } catch (error) { console.log(error) }
  if (reason) {
    await Notification.send(data.device_id, {
      event: 'send-failed::message',
      data: { id: data.id, reason }
    })
  }
}

// Utils.hasEmoji = (text) => {
//   let regex =
//       '/[\x{0080}-\x{02AF}'
//       .'\x{0300}-\x{03FF}'
//       .'\x{0600}-\x{06FF}'
//       .'\x{0C00}-\x{0C7F}'
//       .'\x{1DC0}-\x{1DFF}'
//       .'\x{1E00}-\x{1EFF}'
//       .'\x{2000}-\x{209F}'
//       .'\x{20D0}-\x{214F}'
//       .'\x{2190}-\x{23FF}'
//       .'\x{2460}-\x{25FF}'
//       .'\x{2600}-\x{27EF}'
//       .'\x{2900}-\x{29FF}'
//       .'\x{2B00}-\x{2BFF}'
//       .'\x{2C60}-\x{2C7F}'
//       .'\x{2E00}-\x{2E7F}'
//       .'\x{3000}-\x{303F}'
//       .'\x{A490}-\x{A4CF}'
//       .'\x{E000}-\x{F8FF}'
//       .'\x{FE00}-\x{FE0F}'
//       .'\x{FE30}-\x{FE4F}'
//       .'\x{1F000}-\x{1F02F}'
//       .'\x{1F0A0}-\x{1F0FF}'
//       .'\x{1F100}-\x{1F64F}'
//       .'\x{1F680}-\x{1F6FF}'
//       .'\x{1F910}-\x{1F96B}'
//       .'\x{1F980}-\x{1F9E0}]/u';
//     let match = text.match(regex)
//     //preg_match($emojis_regex, $string, $matches);
//     return match;
// }
