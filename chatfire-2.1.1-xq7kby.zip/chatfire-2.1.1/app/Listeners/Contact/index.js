'use strict'

const Listener = module.exports = {}
const Device = use('App/Models/Device')
const Chatfire = use('Chatfire')
const Ws = use("Ws");

const { filterContact, formatContact, save, remove } = require('./utils')

Listener.sync = async ({ id, contacts }) => {
  const device = await Device.find(id)
  const setting = await device.setting().fetch()

  //if (setting.sync_contact || setting.sync_contact == '1') {
    contacts = Object.values(contacts).filter(filterContact)
    contacts = contacts.map(c => formatContact(id, c))

    await remove(id)
    await save(contacts)
  //}
}

Listener.status = async ({ data }) => {
  data.id = Chatfire.rejid(data.id)
  const channel = Ws.getChannel('chat').topic('chat');
  if(channel){
    channel.socket.broadcastToAll("contact", data);
  }
}