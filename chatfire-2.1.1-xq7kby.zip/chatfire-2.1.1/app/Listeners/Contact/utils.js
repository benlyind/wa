'use strict'

const Utils = module.exports = {}
const Contact = use('App/Models/Contact')
const Chatfire = use('Chatfire')

Utils.save = async (data) => {
  await Contact.createMany(data)
}

Utils.remove = async (id, _) => {
  await Contact
    .query()
    .where('device_id', id)
    .delete()
}

Utils.filterContact = (contact) => {
  return contact &&
    contact.jid !== 'status@broadcast' &&
    contact.verify !== '0' &&
    !Chatfire.isGroup(contact.jid) &&
    Object.keys(contact).length > 1
}

Utils.formatContact = (id, contact) => {
  return {
    device_id: id,
    phone: Chatfire.rejid(contact.jid),
    name: contact.name || contact.short || contact.notify
  }
}
