'use strict'
const Listener = module.exports = {}
const Device = use('App/Models/Device')
const Chatfire = use('Chatfire')
const qrcode = require('qrcode')
const Notification = use('Notification')
const fs = use('fs');

Listener.open = async ({ id, session, user }) => {
  if (typeof session === 'object') {
    session = JSON.stringify(session)
  }

  const device = await Device.find(id)
  let json = session;
  fs.writeFile( 'public/tmp/'+ id + ".json", json, 'utf8',function(err) {
    if (err) throw err;
  });
  device.merge({
    auth: session,
    status: 'PAIRED',
    qr_code: null,
    phone: Chatfire.rejid(user.jid),
    wa_name: user.name,
    wa_version: user.phone.wa_version,
    manufacture: user.phone.device_manufacturer,
    os_version: user.phone.os_version
  })
  await device.save()

  await Notification.send(id, {
    event: 'paired::device',
    data: device
  })
}

Listener.connecting = async ({ id, auth }) => {
  console.log("connecting...")
  Chatfire.login(id, auth)
    const device = await Device.find(id)
    device.merge({ status: 'PAIRING' })
    await device.save()
}

Listener.close = async ({ id, reason, isReconnecting }) => {
  if (reason === 'intentional') return
  if (reason === 'force-unpaired') {
    await Chatfire.logout(id)
  }

  if (reason === 'replaced') {
    const device = await Device.find(id)
    const setting = await device.setting().fetch()
    if (setting.auto_takeover) {
      setTimeout(() => {
        Chatfire.login(id, device.auth)
      }, setting.auto_takeover_delay * 1000);
      return
    }
  }

  const device = await Device.find(id)
  if (reason === 'deleted') {
    try {
      const wa = await Chatfire.pick(id, false)
      await wa.logout()
    } catch (_) { }
    return await device.delete()
  }

  device.merge({ status: 'IDLE', auth: null })
  await device.save()

  await Notification.send(id, {
    event: 'unpaired::device',
    data: { reason, reconnecting: isReconnecting }
  })
}

Listener.qr = async ({ id, qr }) => {
  const device = await Device.find(id)
  const qr_code = await qrcode.toDataURL(qr)
  device.merge({ qr_code })
  await device.save()

  await Notification.send(id, {
    event: 'qr_code::device',
    data: { qr_code }
  })
}

Listener.battery = async ({ id, battery }) => {
  const device = await Device.find(id)
  device.merge({ battery })
  await device.save()

  await Notification.send(id, {
    event: 'battery::device',
    data: { battery }
  })
}

Listener.session_change = async ({ id, session }) => {
  if (typeof session === 'object') {
    session = JSON.stringify(session)
  }

  let json = session;
  fs.writeFile( 'public/tmp/'+ id + ".json", json, 'utf8',function(err) {
    if (err) throw err;
  });
  const device = await Device.find(id)
  device.merge({ auth: session })
  await device.save()
}

Listener.state_change = async ({ id, connected }) => {
  // TODO implement connection phone state changed
}

Listener.reconnect = async ({ id, auth }) => {
  Chatfire.close(id)
  Chatfire.init(id)
  Chatfire.login(id, auth)
}

Listener.failed = async () => {
  console.log('failed')
}