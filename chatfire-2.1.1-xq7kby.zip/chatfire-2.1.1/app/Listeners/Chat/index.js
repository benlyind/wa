'use strict'

const Device = use('App/Models/Device')
const Message = use('App/Models/Message')
const Event = use('Event')
const Listener = module.exports = {}

Listener.sync = async ({ id, chats }) => {
  const device = await Device.find(id)
  const setting = await device.setting().fetch()

  Event.fire('unread::message', { id })
  Event.fire('sync::group', { id })

  if (setting.sync_story) {
    Event.fire('sync::story', { id })
  }
}

Listener.clear = async ({ chat_id }) => {
  await Message
    .query()
    .where('to', chat_id)
    .orWhere('from', chat_id)
    .delete()
}
