'use strict'

const Utils = module.exports = {}

Utils.filterStory = ({ unread }) => {
  unread = parseInt(unread)
  return unread > 0
}

Utils.formatStory = ({ unread, messages }) => {
  unread = parseInt(unread)
  messages = messages.slice(-unread)
  messages = messages.filter(m => m.participant !== '0@s.whatsapp.net')
  return messages
}
