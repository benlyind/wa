'use strict'

const Listener = module.exports = {}
const Chatfire = use('Chatfire')
const Message = require('../Message')
const { filterStory, formatStory } = require('./utils')

Listener.sync = async ({ id }) => {
  try {
    const wa = await Chatfire.pick(id)
    let stories = await wa.getStories()
    stories = stories.filter(filterStory)
    stories = stories.map(s => formatStory(s))
    stories = [].concat(...stories)
    stories.map(async (story) => {
      await Message.receive({ id, message: story })
    })
  } catch (_) { }
}
