// ScheduleTask.js

"use strict";
const Task = use("Task");
const ScheduleController = use("App/Controllers/Http/Dashboard/ScheduleController");

class ScheduleTask extends Task {
  static get schedule() {
     return "*/1 * * * *";
  }

  async handle() {
    try {
      await ScheduleController.cron();
    } catch (e) {
      console.log("Error running task. ", e);
    }
  }
}

module.exports = ScheduleTask;