'use strict'

class RefreshToken {
  get rules() {
    return {
      refresh_token: 'required|string'
    }
  }

  get messages() {
    return {
      'refresh_token.required': 'You must provide a refresh_token',
      'refresh_token.string': 'You must provide a valid refresh_token'
    }
  }

  async fails(error) {
    return this.ctx.response.badRequest(error[0])
  }
}

module.exports = RefreshToken
