'use strict'

class StoreDevice {
  get rules() {
    return {
      name: 'required|string'
    }
  }

  get messages() {
    return {
      'name.required': 'You must provide a name.',
      'name.string': 'This name must be a valid string'
    }
  }

  async fails(error) {
    return this.ctx.response.badRequest(error[0])
  }
}

module.exports = StoreDevice
