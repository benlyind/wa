'use strict'

class Phone {
  get rules() {
    return {
      phone: 'required|string'
    }
  }

  get messages() {
    return {
      'phone.required': 'You must provide a phone number.',
      'phone.string': 'This phone must be a valid string'
    }
  }

  async fails(error) {
    return this.ctx.response.badRequest(error[0])
  }
}

module.exports = Phone
