'use strict'

class SendText {
  get rules() {
    return {
      to: 'required|string',
      message: 'required|string',
      reply_for: 'integer'
    }
  }

  get messages() {
    return {
      'to.required': 'You must provide a recipient phone number.',
      'to.string': 'This to must be a valid string',
      'message.required': 'You must provide a message.',
      'message.string': 'This message must be a valid string',
      'reply_for.integer': 'This reply_for must be a valid id or integer'
    }
  }

  async fails(error) {
    return this.ctx.response.badRequest(error[0])
  }
}

module.exports = SendText
