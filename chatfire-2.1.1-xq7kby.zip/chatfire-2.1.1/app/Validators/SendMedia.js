'use strict'

class SendMedia {
  get rules() {
    return {
      to: 'required|string',
      message: 'required|string',
      media_url: 'required|url',
      type: 'required|in:image,video,document',
      reply_for: 'integer'
    }
  }

  get messages() {
    return {
      'to.required': 'You must provide a recipient phone number.',
      'to.string': 'This to must be a valid string',
      'message.required': 'You must provide a message.',
      'message.string': 'This message must be a valid string',
      'media_url.required': 'You must provide a media_url.',
      'media_url.url': 'This media_url must be a valid url',
      'type.required': 'You must provide a type.',
      'type.in': 'This type must be one of image, video, and document',
      'reply_for.integer': 'This reply_for must be a valid id or integer'
    }
  }

  async fails(error) {
    return this.ctx.response.badRequest(error[0])
  }
}

module.exports = SendMedia
