'use strict'

const { Command } = require('@adonisjs/ace')
const Database = use('Database')
const Hash = use('Hash')

class MakeAdmin extends Command {
  static get signature() {
    return `
      make:admin
      {email? : Email}
      {password? : Password}
    `
  }

  static get description() {
    return 'Make new user as admin'
  }

  async handle(args, options) {
    let { email, password } = args

    email = email || await this.ask('Enter email')
    password = password || await this.secure('Enter password')
    password = await Hash.make(password)
    const users = await Database.from('users').where('email', email)
    if(!users.length){
      await Database
        .table('users')
        .insert({
          email,
          password,
          role: 'admin',
          created_at: Database.fn.now(),
          updated_at: Database.fn.now()
        })

      this.info('New admin created!')
    }else{
      this.info('Admin already created before!')
    }
    await Database.close()
  }
}

module.exports = MakeAdmin
