'use strict'
const Event = use('Event')
const Ws = use("Ws");

class ChatController {
  constructor ({ socket, request }) {
    this.socket = socket
    this.request = request
  }

  onMessage (message) {
    Event.once('received::message', async (msg) => {
      console.log('event',msg);
      this.socket.emit(
        "message",
        msg
      );
    })
  }
  onReceivedMessage (message) {
    Event.once('received::message', async (msg) => {
      console.log('event',msg);
      this.socket.emit(
        "message",
        msg
      );
    })
  }
}

module.exports = ChatController
