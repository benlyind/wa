'use strict'

const Group = use('App/Models/Group')

class GroupController {
  async index({ request, response, view }) {
    const { device_id } = request
    const { page, limit, sort_by, order_by } = request.query
    const fields = ['id', 'name', 'owner', 'created_at', 'updated_at']

    return await Group
      .query()
      .byDevice(device_id)
      .orderBy(sort_by(fields), order_by)
      .paginate(page, limit)
  }

  async store({ request, response }) {
  }

  async show({ params, request, response, view }) {
    const { device_id } = request
    const { id } = params

    return await Group
      .query()
      .byDevice(device_id)
      .where({ id })
      .firstOrFail()
  }
}

module.exports = GroupController
