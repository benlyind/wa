'use strict'

const User = use('App/Models/User')

class AuthController {
  async login({ auth, request }) {
    const { email, password } = request.all()
    return await auth
      .authenticator('jwt')
      .withRefreshToken()
      .attempt(email, password)
  }

  async logout({ auth, request }) {
    const token = auth.getAuthHeader()
    return await auth
      .revokeTokens([token])
  }

  async register({ auth, request }) {
    const { email, password } = request.all()
    return await User.create({ email, password })
  }

  async me({ auth }) {
    return await auth.getUser()
  }

  async refresh({ auth, request }) {
    const { refresh_token } = request.only(['refresh_token'])

    return await auth
      .newRefreshToken()
      .generateForRefreshToken(refresh_token)
  }
}

module.exports = AuthController
