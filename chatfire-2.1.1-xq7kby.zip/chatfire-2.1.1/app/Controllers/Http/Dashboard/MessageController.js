'use strict'
const Logger = use('Logger')
const Axios = use('axios');
const Env = use('Env')
const Event = use('Event')
const Message = use('App/Models/Message')
const Device = use('App/Models/Device')
const Config = use('Config')
const DeviceStatus = Config.get('device.status')
const Database = use('Database')
const Chatfire = use('Chatfire')
const path = use('path')
const https = use('https')
const fs = use('fs')

class MessageController {
    async index({ view, request, response, params, session }) {
        try{
        if(!request.cookie('token')){
            return response.redirect('/login')
        }
        const { phone } = params
        let data = {};
        let devices;
        if(session.get('role') == 'agent'){
            devices = await Database
                .select('devices.*')
                .table('devices')
                .innerJoin('agents', function () {
                    this
                    .on('devices.id', 'agents.device_id')
                })
                .where('user_id', session.get('user_id'))
                .orderBy('name', 'asc')
        }else{
            devices = await Database
                .select('devices.*')
                .table('devices')
                .where('owner_id', session.get('user_id'))
                .orderBy('name', 'asc')
        }
        if(devices.length > 0){
            let contact = await Database
              .table('contacts')
              .orderBy('name', 'asc')
            data.devices = devices;
            data.path    = 'message';
            data.phone   = phone;
            data.contact = contact;
            data.role    = session.get('role')
            return view.render('message.index', data)
        }else{
          let res       = {}
          res.path      = 'message';
          res.role      = session.get('role')
          return view.render('chat.empty', res)
        }
    }catch(e){
        console.log(e)
    }
    }

    async store({ view, session, request, response }) {
        const { device_id, to, message } = request.all()
        
        if(!to || !message ){
            session.flash({ notification: 'Failed, Please fill all form', tag: 'error' })
        }else{
            let sender_name = session.get('name') ? session.get('role') : null; 
            if(Array.isArray(to)){
                for (let phone of to) { // You can use `let` instead of `const` if you like
                    let reply_for;
                    let quoted
                    let to = phone;
                    const newMessage = await Message.create({
                          device_id,
                          to,
                          message,
                          type: 'text',
                          from_me: true,
                          from_group: Chatfire.isGroup(to),
                          reply_for,
                          sender_name
                        })
                    const savedMessage = await Message.find(newMessage.id)
                    Event.fire('send::message', { id: device_id, data: savedMessage, quoted })
                    session.flash({ notification: 'Success, Message has been sent to ' + to, tag: 'success' })
                }
            }else{
                let reply_for;
                let quoted
                const newMessage = await Message.create({
                      device_id,
                      to,
                      message,
                      type: 'text',
                      from_me: true,
                      from_group: Chatfire.isGroup(to),
                      reply_for,
                      sender_name
                    })
                const savedMessage = await Message.find(newMessage.id)
                Event.fire('send::message', { id: device_id, data: savedMessage, quoted })
                session.flash({ notification: 'Success, Message has been sent to ' + to, tag: 'success' })
            }
        }
        return response.redirect('/message')
    }
}

module.exports = MessageController