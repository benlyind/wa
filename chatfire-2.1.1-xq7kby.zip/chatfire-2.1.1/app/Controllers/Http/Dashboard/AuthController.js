'use strict'
const Logger = use('Logger')
const Chatfire = use('Chatfire')
const Axios = use('axios');
const https = use('https')
const path = use('path')
const fs = use('fs')
const Env = use('Env')

class AuthController {
  index({ view, auth }) {
      let user = auth.user;
      return view.render('auth.index', { user })
  }
  license({ view, auth }) {
      return view.render('auth.license')
  }
  async licensing({request, session, response }) {
    const { license } = request.all()
    const res         = await Chatfire.licensing(license)
    Logger.info('result  %s', res)
    if(res.code == '300'){
      return response.redirect('/')
    }else{
      session.flash({ notification: 'Failed, '+ res.message , tag: 'error' })
      return response.redirect('/license')
    }
  }
  async login({ request, auth, session, response }) {
    try{
    const { email, password } = request.all()
    let res = await auth.attempt(email, password);
    let cert_file = fs.readFileSync(path.join(__dirname, '../../../../certificate.crt'))
    const agent = new https.Agent({
        requestCert: true,
        rejectUnauthorized: false,
        cert: cert_file
    });
    let me = await Axios( Env.get('APP_URL') + '/api/auth/me',{
        headers: {
           'content-type': "application/application.json",
           'Authorization': 'Bearer ' + res.token
         },
             httpsAgent: agent
        })
        .then(response => {
            return response
        });
    session.put('role', me.data.role)
    session.put('user_id', me.data.id)
    session.put('user_name', me.data.name)
    response.cookie('token', res.token)
    response.plainCookie('tkn', res.token)
    return response.redirect('/')
  }catch(e){
    console.log(e)
  }
  }
  async logout({ response }){
    response.clearCookie('token')
    response.clearCookie('tkn')
    return response.redirect('/')
  }
}

module.exports = AuthController