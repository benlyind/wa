'use strict'
const Logger = use('Logger')
const Axios = use('axios');
const Env = use('Env')
const Event = use('Event')
const Contact = use('App/Models/Contact')
const Device = use('App/Models/Device')
const Config = use('Config')
const DeviceStatus = Config.get('device.status')
const Database = use('Database')
const Chatfire = use('Chatfire')

class ContactController {
  async index({ view, auth, request, params, session }) {
      let { page, query} = request.query
      const fields = ['id', 'name', 'phone']
      if(!request.cookie('token')){
          return response.redirect('/login')
      }
      if(!query){
          query = '';
      }
      i = 0;
      let data = await Database
        .select('contacts.*','devices.name as device', 'tags.name as tags')
        .table('contacts')
        .leftOuterJoin('devices', 'contacts.device_id', 'devices.id')
        .leftOuterJoin('tag_details', 'contacts.id', 'tag_details.contact_id')
        .leftOuterJoin('tags', 'tag_details.tag_id', 'tags.id')
        //.where('contacts.name','LIKE', '%'+query+'%')
        .orderBy('name', 'asc')
        .paginate(page, 5);
      let total = await Database
        .from('contacts')
        //.where('name','LIKE', '%'+query+'%')
        .count();

      for (const val of data.data) {
        let ppUrl;
        let status = null;
        if(!val.ppUrl){
          try {
            const wa = await Chatfire.pick(val.device_id)
            ppUrl = await wa.getProfilePicture(Chatfire.jid(val.phone))
          } catch (error) {
            ppUrl = null;
          }
          data.data[i].ppUrl = ppUrl;
          await Database.table('contacts').where('id', val.id).update({ ppUrl: ppUrl, status: status })
        }
        i++;
      }
      data.path = 'contacts';
      data.total = total[0].count;
      var length = data.total / 5;   
      let paginate = []
      data.number       = 3;
      data.start_number = page > data.number ? page - 3 : 1;
      data.end_number   = (page < (length - data.number))? page + data.number : length;
      for (var i = data.start_number; i <= data.end_number; i++) {
        paginate.push(i);
      }
      // for (var i = 1; i <= length; i++) {
      //   paginate.push(i);
      // }
      data.paginate = paginate;
      data.current  = page;
      data.query    = query;
      data.role     = session.get('role')
      return view.render('contacts.index', data)
  }

  async import({ request,response,session }){
    let { name, group_id,device_id } = request.all()
    const device = await Device.findBy('device_key',device_id)
    const jid    = Chatfire.jid(group_id)
    const wa     = await Chatfire.pick(device.id)

    let message  = wa.chats.get(jid)

    if(!name){
      name = message.metadata.subject;
    }

    try{
      let tag_name = await Database
                .select('*')
                .table('tags')
                .where('name', name.substr(0, 10))

      let tag_id;
      let contact_id
      if(tag_name.length < 1){
        tag_id = await Database
        .table('tags')
        .insert({device_id: device.id, name: name.substr(0, 10) }).returning('id')
        tag_id = tag_id[0]
      }else{
        tag_id = tag_name[0].id
      }
      let tg_id = tag_id;
      for (let contact of message.metadata.participants){
        let contact_name = wa.chats.get(contact.jid)
        let contact_number = contact.jid.replace('@s.whatsapp.net','');
        let contact_item = await Database
                .select('*')
                .table('contacts')
                .where('phone', contact_number)
        if(contact_item.length < 1){
          contact_id = await Database
          .table('contacts')
          .insert({phone: contact_number }).returning('id')

          contact_id = contact_id[0]
          let tags_detail = await Database
                .select('*')
                .table('tag_details')
                .where('contact_id', contact_id)
                .where('tag_id', tg_id)
           if(tags_detail.length < 1){
              await Database
              .table('tag_details')
              .insert({tag_id: tg_id, contact_id: contact_id })
           }
        }
      }
      session.flash({ notification: 'Success, You have imported '+ message.metadata.participants.length +' contacts', tag: 'succes' })
      return response.redirect('/contacts')
    }catch(e){
      console.log(e)
    }
  }
}

module.exports = ContactController