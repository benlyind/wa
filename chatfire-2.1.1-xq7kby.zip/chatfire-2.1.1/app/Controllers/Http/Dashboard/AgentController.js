"use strict";
const Logger = use("Logger");
const Database = use('Database')
const Axios = use('axios');
const Env = use('Env')
const Message = use('App/Models/Message')
const Chatfire = use('Chatfire');
const Event = use('Event')
const dateFormat = use('dateformat');
const path = use('path')
const https = use('https')
const fs = use('fs')
const User = use('App/Models/User')
const Agent = use('App/Models/Agent')

class AgentController {
  async index({ view, auth, request, session }){
    const { page} = request.query
    if(!request.cookie('token')){
        return response.redirect('/login')
    }
    let data = await Database
          .select('users.*','agents.status','devices.name as device')
          .table('users')
          .innerJoin('agents', function () {
            this
              .on('users.id', 'agents.user_id')
          })
          .innerJoin('devices', function () {
            this
              .on('agents.device_id', 'devices.id')
          })
          .where('role', 'agent')
          .orderBy('id', 'desc')
          .paginate(page, 10)
    let cert_file = fs.readFileSync(path.join(__dirname, '../../../../certificate.crt'))
        const agent = new https.Agent({
            requestCert: true,
            rejectUnauthorized: false,
            cert: cert_file
        });
    let devices = await Axios( Env.get('APP_URL') + '/api/devices',{
        headers: {
           'content-type': "application/application.json",
           'Authorization': 'Bearer ' + request.cookie('token')
         },
             httpsAgent: agent
        })
        .then(response => {
            return response
        });
    if(devices.data.total > 0){
      data.devices = devices.data.data;
      data.path = 'agent';
      let i =0;
      for (const val of data.data) { // You can use `let` instead of `const` if you like
        if(val.message_id){
          let msg = await Message.findBy('id', val.message_id)
          data.data[i].status = msg.status
        }
        i++;
      }
      data.role = session.get('role')
      if(data.role == 'agent'){
        return response.redirect('/')
      }
      return view.render('agent.index', data)
    }else{
      let res       = {}
      res.path      = 'agent';
      return view.render('chat.empty', res)
    }
  }

  async store({ view, session, request, response }){
    const { name,email, password, device } = request.all()
    if(!name || !device || !email || !password ){
        session.flash({ notification: 'Failed, Please fill all form', tag: 'error' })
    }else{
      try{
        const neUser = await User.create({ name, email, password, 'role':'agent' })
        if(Array.isArray(device)){
          for (let phone of device) {
            Agent.create({device_id:phone, user_id:neUser.id});
          }
        }
        session.flash({ notification: 'Success, Agent added successfully', tag: 'success' })
      }catch(e){
        session.flash({ notification: 'Failed, '+ e.detail, tag: 'error' })
      }
    }
    return response.redirect('/agent')
  }
  async delete({ params, request, response }){
    const { id } = params
    
    const affectedRows = await Database
    .table('agent')
    .where('id', id)
    .delete()
    return response.redirect('/agent')
  }
}
module.exports = new AgentController();