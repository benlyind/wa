'use strict'
const Logger = use('Logger')
const Axios = use('axios');
const Env = use('Env')
const Event = use('Event')
const Device = use('App/Models/Device')
const Config = use('Config')
const DeviceStatus = Config.get('device.status')
const Database = use('Database')
const path = use('path')
const https = use('https')
const fs = use('fs')

class WebhooksController {
    async index({ view, auth, request, session }) {
        const { page} = request.query
        if(!request.cookie('token')){
            return response.redirect('/login')
        }
        let data = await Database
          .select('webhooks.*','devices.name as device')
          .table('webhooks')
          .innerJoin('devices', 'webhooks.device_id', 'devices.id')
          .paginate(page, 10)
        let cert_file = fs.readFileSync(path.join(__dirname, '../../../../certificate.crt'))
        const agent = new https.Agent({
            requestCert: true,
            rejectUnauthorized: false,
            cert: cert_file
        });
        let devices = await Axios( Env.get('APP_URL') + '/api/devices',{
            headers: {
               'content-type': "application/application.json",
               'Authorization': 'Bearer ' + request.cookie('token')
             },
             httpsAgent: agent
            })
            .then(response => {
                return response
            });
        if(devices.data.total > 0){
            data.devices = devices.data.data;
            Logger.info('result  %s', data.devices)
            data.path = 'webhooks';
            data.role = session.get('role')
            if(data.role == 'agent'){
                return response.redirect('/')
            }
            return view.render('webhooks.index', data)
        }else{
          let res       = {}
          res.path      = 'webhooks';
          return view.render('chat.empty', res)
        }
    }

    async store({ view, session, request, response }) {
        const { device, url } = request.all()
        
        if(!url){
            session.flash({ notification: 'Failed, Please fill all form', tag: 'error' })
        }else{
            // const messageId = await Database
            //   .table('webhooks')
            //   .insert({device_id: device, url: url})
            let id = device;
            const devices = await Device.query().where({ id }).first()
            const webhook = await devices.webhook().fetch()

            
            if (!webhook.url || webhook.url !== url) {
              webhook.url = url
            }
            Logger.info('webhook  %s', webhook.url)

            await webhook.save()
            session.flash({ notification: 'Success, New webhook has been added', tag: 'success' })
        }
        return response.redirect('/webhooks')
    }
}

module.exports = WebhooksController