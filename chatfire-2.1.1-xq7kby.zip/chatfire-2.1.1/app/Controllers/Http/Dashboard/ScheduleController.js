"use strict";
const Logger = use("Logger");
const Database = use('Database')
const Axios = use('axios');
const Env = use('Env')
const Message = use('App/Models/Message')
const Chatfire = use('Chatfire');
const Event = use('Event')
const dateFormat = use('dateformat');
const path = use('path')
const https = use('https')
const fs = use('fs')

class ScheduleController {
  async cron() {
    let data = await Database
      .table('schedules')
      .where('time', dateFormat(new Date(), "yyyy-mm-dd h:MM"))
      .first()
    if(data){
      let reply_for;
      let quoted
      let to = data.phone;
      let message = data.message;
      let device_id = data.device_id;
      let sender_name = 'system'; 
      const newMessage = await Message.create({
            device_id,
            to,
            message,
            type: 'text',
            from_me: true,
            from_group: Chatfire.isGroup(to),
            reply_for,
            sender_name
          })
      const savedMessage = await Message.find(newMessage.id)
      Event.fire('send::message', { id: device_id, data: savedMessage, quoted })
      await Database
      .table('schedules')
      .where('id', data.id)
      .update('message_id', newMessage.id)
    }
  }

  async index({ view, auth, request, session }){
    const { page} = request.query
    if(!request.cookie('token')){
        return response.redirect('/login')
    }
    let data = await Database
          .select('schedules.*','devices.name as device')
          .table('schedules')
          .innerJoin('devices', 'schedules.device_id', 'devices.id')
          .orderBy('id', 'desc')
          .paginate(page, 10)
    let cert_file = fs.readFileSync(path.join(__dirname, '../../../../certificate.crt'))
        const agent = new https.Agent({
            requestCert: true,
            rejectUnauthorized: false,
            cert: cert_file
        });
    let devices = await Axios( Env.get('APP_URL') + '/api/devices',{
        headers: {
           'content-type': "application/application.json",
           'Authorization': 'Bearer ' + request.cookie('token')
         },
             httpsAgent: agent
        })
        .then(response => {
            return response
        });
    if(devices.data.total > 0){
      data.devices = devices.data.data;
      data.path = 'schedule';
      let i =0;
      for (const val of data.data) { // You can use `let` instead of `const` if you like
        if(val.message_id){
          let msg = await Message.findBy('id', val.message_id)
          data.data[i].status = msg.status
        }
        i++;
      }
      data.role = session.get('role')
      if(data.role == 'agent'){
        return response.redirect('/')
      }
      return view.render('schedule.index', data)
    }else{
      let res       = {}
      res.path      = 'schedule';
      return view.render('chat.empty', res)
    }
  }

  async store({ view, session, request, response }){
    const { device, phone, time, message } = request.all()
    if(!phone || !time || !message ){
        session.flash({ notification: 'Failed, Please fill all form', tag: 'error' })
    }else{
      const scheduleId = await Database
        .table('schedules')
        .insert({device_id: device, phone: phone, time:dateFormat(new Date(time), "yyyy-mm-dd h:MM"), message:message, status: 'PENDING' })
    }
    return response.redirect('/schedule')
  }
  async delete({ params, request, response }){
    const { id } = params
    
    const affectedRows = await Database
    .table('schedules')
    .where('id', id)
    .delete()
    return response.redirect('/schedule')
  }
}
module.exports = new ScheduleController();