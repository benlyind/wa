'use strict'
const Logger = use('Logger')
const Axios = use('axios');
const Env = use('Env')
const Event = use('Event')
const Contact = use('App/Models/Contact')
const Config = use('Config')
const DeviceStatus = Config.get('device.status')
const Database = use('Database')
const path = use('path')
const https = use('https')
const fs = use('fs')

class AutoRepliesController {
    async index({ view, auth, request, session }) {
        const { page} = request.query
        if(!request.cookie('token')){
            return response.redirect('/login')
        }
        let data = {};
        try{
            data = await Database
          .select('auto_replies.*','devices.name as device')
          .table('auto_replies')
          .innerJoin('devices', "auto_replies.device_id", "devices.id")
          .paginate(page, 10)
        }catch(e){
            console.log(e)
        }

        let cert_file = fs.readFileSync(path.join(__dirname, '../../../../certificate.crt'))
        const agent = new https.Agent({
            requestCert: true,
            rejectUnauthorized: false,
            cert: cert_file
        });
        let devices = await Axios( Env.get('APP_URL') + '/api/devices',{
            headers: {
               'content-type': "application/application.json",
               'Authorization': 'Bearer ' + request.cookie('token')
            },
             httpsAgent: agent
            })
        console.log( data )
        if(devices.data.total > 0){
            data.devices = devices.data.data;
            Logger.info('result  %s', data.devices)
            data.path = 'auto-replies';
            data.role = session.get('role')
            if(data.role == 'agent'){
                return response.redirect('/')
            }
            return view.render('auto-replies.index', data)
        }else{
          let res       = {}
          res.path      = 'auto-replies';
          return view.render('chat.empty', res)
        }
    }

    async store({ view, session, request, response }) {
        const { device, keyword, message } = request.all()
        
        if(!keyword || !message ){
            session.flash({ notification: 'Failed, Please fill all form', tag: 'error' })
        }else{
            const messageId = await Database
              .table('auto_replies')
              .insert({device_id: device, keyword: keyword, message: message})
            session.flash({ notification: 'Success, New message has been added', tag: 'success' })
        }
        return response.redirect('/auto-replies')
    }
    async delete({ params, request, response }){
        const { id } = params
        
        const affectedRows = await Database
        .table('auto_replies')
        .where('id', id)
        .delete()
        return response.redirect('/auto-replies')
    }
}

module.exports = AutoRepliesController