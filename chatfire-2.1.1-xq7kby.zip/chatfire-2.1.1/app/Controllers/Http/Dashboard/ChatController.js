'use strict'
const Logger = use('Logger')
const Axios = use('axios');
const Env = use('Env')
const Event = use('Event')
const Device = use('App/Models/Device')
const Message = use('App/Models/Message')
const Group = use('App/Models/Group')
const Config = use('Config')
const Database = use('Database')
const Chatfire = use('Chatfire')
const moment = use('moment')
const Helpers = use('Helpers')
const FileType = require('file-type')
const path = use('path')
const https = use('https')
const fs = use('fs')

class ChatController {
  async index({ view, auth, request, params, response, session }) {
    if(!request.cookie('token')){
          return response.redirect('/login')
      }
    try{
      let devices;
      if(session.get('role') == 'agent'){
          devices = await Database
              .select('devices.*')
              .table('devices')
              .innerJoin('agents', function () {
                  this
                  .on('devices.id', 'agents.device_id')
              })
              .where('user_id', session.get('user_id'))
              .orderBy('name', 'asc')
      }else{
          devices = await Database
              .select('devices.*')
              .table('devices')
              .where('owner_id', session.get('user_id'))
              .orderBy('name', 'asc')
      }
   
      if(devices.length > 0){
        if(params.device_key == null || params.device_key == undefined){
          if(devices){
            return response.redirect('/chat/'+devices[0].device_key)
          }
        }else{
          const device = await Device.findBy('device_key',params.device_key)
          let { id }   = device
          let res      = {};
          let wa;
          try{
            wa     = await Chatfire.pick(id)
          } catch (error) {
            let res       = {}
            res.path      = 'chat';
            res.role      = session.get('role')
            return view.render('chat.empty', res)
          }
          const {chats, cursor} = wa.loadChats(10)
          let data     = chats.map(this.format)
          let i        = 0;
          let unread   = 0;
          let j        = 0 ;
          for (const dev of devices){
            try {
              let dread    = await Database.raw("select count(*) as total from messages where from_me = '0' and status != 'READ' and device_id = "+ dev.id +";");
              if(dread.rowCount > 0){
                devices[j].unread = dread.rows[0].total;
              }
            } catch (error) {
              console.log("jas", error)
            }
            j++;
          }
          for (const val of data) {
            let ppUrl = 'https://www.seekpng.com/png/detail/428-4287240_no-avatar-user-circle-icon-png.png';
            try {
              const wa = await Chatfire.pick(id)
              ppUrl    = await wa.getProfilePicture(val.id)
              data[i].ppUrl = ppUrl;
            } catch (error) {
         
            }
            try {
              unread    = await Database.raw("select count(*) as total from messages where from_me = '0' and status != 'READ' and device_id = '"+id+"' and \"from\" = '"+ val.id +"';")
              if(unread.rowCount > 0){
                data[i].unread = unread.rows[0].total;
              }
            } catch (error) {
            }
            i++;
          }
          if(params.id){
            let jid           = Chatfire.jid(params.id);
            const wa          = await Chatfire.pick(id)
            const chat        = await wa.chats.get(jid);
            let official      = false;
            let lastMessage   = [...chat.messages.array].pop();
            let isGroup       = Chatfire.isGroup(jid);
            if(isGroup){
              chat.name   = chat.metadata.subject;
              chat.member = chat.metadata.participants
            }else{
              if(lastMessage && lastMessage.messageStubParameters.length){
                chat.name = lastMessage.messageStubParameters[0] ;
                official  = true;
              }
            }
            res.header          = chat;
            res.isGroup         = isGroup;
            res.header.official = official;
            await Database.raw("UPDATE messages SET status='READ' WHERE from_me = '0' and \"from\" = '"+ params.id +"';")
            await wa.chatRead(jid)
            try {
              res.header.ppUrl    = await wa.getProfilePicture(jid)
            } catch (error) {
              console.log(error);
            }
            res.header.status   = await wa.getStatus(jid)
          }
          res.data      = data;
          res.id        = params.id;
          res.device    = params.device_key
          res.device_id = id
          res.devices   = devices
          res.path      = 'chat';
          res.title     = 'Chats';
          res.cursor    = cursor
          res.role     = session.get('role')
          return view.render('chat.index',res)
        }
      }else{
        let res       = {}
        res.path      = 'chat';
        res.role      = session.get('role')
        return view.render('chat.empty', res)
      }
    }catch(e){
      console.log(e)
    }
  }
  async group({ view, auth, request, params, response, session }) {
    if(!request.cookie('token')){
          return response.redirect('/login')
      }
    try{
      let devices;
      if(session.get('role') == 'agent'){
          devices = await Database
              .select('devices.*')
              .table('devices')
              .innerJoin('agents', function () {
                  this
                  .on('devices.id', 'agents.device_id')
              })
              .where('user_id', session.get('user_id'))
              .orderBy('name', 'asc')
      }else{
          devices = await Database
              .select('devices.*')
              .table('devices')
              .where('owner_id', session.get('user_id'))
              .orderBy('name', 'asc')
      }
   
      if(devices.length > 0){
        if(params.device_key == null || params.device_key == undefined){
          if(devices){
            return response.redirect('/groups/'+devices[0].device_key)
          }
        }else{
          const device = await Device.findBy('device_key',params.device_key)
          let { id }   = device
          let res      = {};
          let wa;

          try{
            wa     = await Chatfire.pick(id)
          } catch (error) {
            let res       = {}
            res.path      = 'chat';
            res.role      = session.get('role')
            return view.render('chat.empty', res)
          }
          let groups = await Chatfire.groups(wa)

          let data   = groups.map(this.format);
          let i        = 0;
          let unread   = 0;
          let j        = 0 ;
          for (const dev of devices){
            try {
              let dread    = await Database.raw("select count(*) as total from messages where from_me = '0' and status != 'READ' and device_id = "+ dev.id +";");
              if(dread.rowCount > 0){
                devices[j].unread = dread.rows[0].total;
              }
            } catch (error) {
              
            }
            j++;
          }
          for (const val of data) {
            let ppUrl = 'https://www.seekpng.com/png/detail/428-4287240_no-avatar-user-circle-icon-png.png';
            try {
              const wa = await Chatfire.pick(id)
              ppUrl    = await wa.getProfilePicture(val.id)
              data[i].ppUrl = ppUrl;
            } catch (error) {
         
            }
            try {
              unread    = await Database.raw("select count(*) as total from messages where from_me = '0' and status != 'READ' and device_id = '"+id+"' and \"from\" = '"+ val.id +"';")
              if(unread.rowCount > 0){
                data[i].unread = unread.rows[0].total;
              }
            } catch (error) {
            }
            i++;
          }
          if(params.id){
            let jid           = Chatfire.jid(params.id);
            const wa          = await Chatfire.pick(id)
            const chat        = wa.chats.get(jid);
            console.log(chat)
            let official      = false;
            let lastMessage   = [...chat.messages.array].pop();
            let isGroup       = Chatfire.isGroup(jid);
            if(isGroup){
              chat.name   = chat.metadata.subject;
              chat.member = chat.metadata.participants
            }else{
              if(lastMessage && lastMessage.messageStubParameters.length){
                chat.name = lastMessage.messageStubParameters[0] ;
                official  = true;
              }
            }
            res.header          = chat;
            res.isGroup         = isGroup;
            res.header.official = official;
            await Database.raw("UPDATE messages SET status='READ' WHERE from_me = '0' and \"from\" = '"+ params.id +"';")
            await wa.chatRead(jid)
            try {
              res.header.ppUrl    = await wa.getProfilePicture(jid)
            } catch (error) {
              console.log(error);
            }
            res.header.status   = await wa.getStatus(jid)
          }
          res.data      = data;
          res.id        = params.id;
          res.device    = params.device_key
          res.device_id = id
          res.devices   = devices
          res.path      = 'chat';
          res.title     = 'Groups';
          // res.cursor    = cursor
          res.role     = session.get('role')
          return view.render('chat.index',res)
        }
      }else{
        let res       = {}
        res.path      = 'chat';
        res.role      = session.get('role')
        return view.render('chat.empty', res)
      }
    }catch(e){
      //console.log(e)
    }
  }
  async store({request, params, response, session}){
    let { to, device,message } = request.all()
    const the_device = await Device.findBy('device_key',device)
    let { id }   = the_device
    const file = request.file('file', {
      types: ['image','video','pdf','vnd.ms-excel'],
      size: '20mb'
    })
    await file.move(Helpers.publicPath('uploads'), {
      name: file.clientName,
      overwrite: true
    })

    if (!file.moved()) {
      return file.error()
    }
    let url = Env.get('APP_URL') + '/uploads/'+file.clientName;
    let media_url = url
    let device_id = id
    let type      = null
    if(file.extname == 'gif' || file.extname == 'mp4'){
      type = 'video';
    }else if(file.extname == 'pdf'){
      type = 'document';
      if(!message){
        message = file.fileName
      }
    }else{
      type = 'image';
    }
    let reply_for   = null;
    let sender_name = session.get('name') ? session.get('role') : null; 
    try{
      const newMessage = await Message.create({
        device_id,
        to,
        message,
        media_url,
        type,
        from_me: true,
        from_group: Chatfire.isGroup(to),
        reply_for,
        sender_name
      })
      const savedMessage = await Message.find(newMessage.id)

      let quoted
      if (reply_for) {
        quoted = await Message.find(reply_for)
      }  


      console.log("savedMessage",savedMessage);

      Event.fire('send::message', { id: device_id, data: savedMessage, quoted })
      return await Message.find(newMessage.id);
    } catch(error){
      console.log(error)
    }
  }

  async show({ params,response }) {
    let message = await Message.findBy('wa_id', params.wid);
    try{
      let mime = await FileType.fromFile( Helpers.publicPath() + message.media_url);
      response.header('Content-type', mime.mime)
      response.type(mime.mime)
      response.download(Helpers.publicPath() + message.media_url)
    }catch(e){
       console.log(e)
    }
  }


  toBase64(arr) {
     //arr = new Uint8Array(arr) if it's an ArrayBuffer
     return btoa(
        arr.reduce((data, byte) => data + String.fromCharCode(byte), '')
     );
  }

  format({ jid, name, messages, metadata }) {
    const id = Chatfire.rejid(jid)
    const is_group = Chatfire.isGroup(jid)
    let lastMessage = [...messages.array].pop();
    let official = false;
    if(is_group && metadata){
      name  = metadata.subject
    }else{
      if(lastMessage && lastMessage.messageStubParameters.length){
        name = lastMessage.messageStubParameters[0]
        //official = true;
      }
    }
    let time = moment().format("H:mm");
    if(lastMessage){
      let last = new Date(lastMessage.messageTimestamp.low * 1000);
      time = moment(last).format("H:mm");
    }
    return {
      id,
      name: name || id,
      is_group,
      lastMessage,
      time,
      official
    }
  }
  async formatgroup({ id, name, participants, device_id }) {
    const jid      = Chatfire.jid(id)
    const is_group = Chatfire.isGroup(jid)
    const wa       = await Chatfire.pick(device_id)
    let message   = wa.chats.get(jid)
    let lastMessage = [...message.messages.array].pop();
    let official = false;
    if(is_group && message.metadata){
      name  = message.metadata.subject
    }else{
      if(lastMessage && lastMessage.messageStubParameters.length){
        name = lastMessage.messageStubParameters[0]
        //official = true;
      }
    }
    let time = moment().format("H:mm");
    if(lastMessage){
      let last = new Date(lastMessage.messageTimestamp.low * 1000);
      time = moment(last).format("H:mm");
    }

    return {
      id,
      name: name || id,
      is_group,
      lastMessage,
      time,
      official
    }
  }
  async getImage(id){
    const wa = await Chatfire.pick(device_id)
    let ppUrl = await wa.getProfilePicture(id)
    return ppUrl;
  }
}

module.exports = ChatController