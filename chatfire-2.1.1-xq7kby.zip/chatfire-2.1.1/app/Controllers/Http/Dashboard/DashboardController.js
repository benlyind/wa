'use strict'
const Logger = use('Logger')
const Axios = use('axios');
const Env = use('Env')
const Event = use('Event')
const Device = use('App/Models/Device')
const Config = use('Config')
const DeviceStatus = Config.get('device.status')
const Database = use('Database')

class DashboardController {
    async index({ view, auth, request, response, session }) {
        if(!request.cookie('token')){
            return response.redirect('/login')
        }
        try {
            let data = {};
            let message = await Database
              .select('messages.*','devices.name as device')
              .table('messages')
              .innerJoin('devices', 'messages.device_id', 'devices.id')
              .orderBy('id', 'desc')
              .limit(10)
            let statistic = await Database
              .raw("select devices.id, devices.name, (select count(*) from messages where device_id = devices.id and from_me = '1') as total, (select count(*) from messages where device_id = devices.id and from_me = '0') as received from devices")
            let cart = await Database
              .raw('SELECT extract(month from created_at) as month, count(*) as total FROM messages GROUP BY extract(year from created_at), extract(month from created_at)')
            data.path = '';
            data.message = message;
            let staticart = [];
            for (let index = 1; index <= 12; ++index) {
                if(Env.get('DB_CONNECTION') == 'pg'){
                    cart.rows.forEach((entry) => {
                        if(index == entry.month){
                            staticart[index] = entry.total;
                        }else{
                            staticart[index] = 0;
                        }
                    });
                }else if(Env.get('DB_CONNECTION') == 'mysql'){
                    if(cart.data){
                        cart.data.forEach((entry) => {
                            if(index == entry.month){
                                staticart[index] = entry.total;
                            }else{
                                staticart[index] = 0;
                            }
                        });
                    }
                }
            }
            if(Env.get('DB_CONNECTION') == 'pg'){
                data.statistic = statistic.rows;
            }else if(Env.get('DB_CONNECTION') == 'mysql'){
                data.statistic = statistic.data;
            }
            staticart.shift();
            data.cart = staticart;
            data.role = session.get('role')
            return view.render('home.index', data)
        } catch(error){
            console.log(error)
            return response.redirect('/login')
        }
    }

    async getQR({ params,response }) {
        try {
            const device = await Device.find(params.id)
            let { status, qr_code } = device
            const data = {
              status,
              qr_code
            }
            return response.send("data: "+ JSON.stringify(data) +"\n\n")
        } catch(error){
            return error
        }
    }
}

module.exports = DashboardController