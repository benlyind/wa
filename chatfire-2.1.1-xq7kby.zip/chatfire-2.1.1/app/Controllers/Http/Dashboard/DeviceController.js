'use strict'
const Logger = use('Logger')
const Axios = use('axios');
const Env = use('Env')
const Event = use('Event')
const Device = use('App/Models/Device')
const Config = use('Config')
const DeviceStatus = Config.get('device.status')
const Chatfire = use('Chatfire')
const path = use('path')
const https = use('https')
const fs = use('fs')

class DeviceController {
    async index({ view, auth, request,response, session }) { 
        if(!request.cookie('token')){
            return response.redirect('/login')
        }
        try {
            let cert_file = fs.readFileSync(path.join(__dirname, '../../../../certificate.crt'))
            const agent = new https.Agent({
                requestCert: true,
                rejectUnauthorized: false,
                cert: cert_file
            });
            let data = await Axios( Env.get('APP_URL') + '/api/devices',{
             headers: {
               'content-type': "application/application.json",
               'Authorization': 'Bearer ' + request.cookie('token')
             },
             httpsAgent: agent
            })
            .then(response => {
                return response
            });
            data.path  = 'devices';
            data.token = request.cookie('token')
            data.role  = session.get('role')
            if(data.role == 'agent'){
                return response.redirect('/')
            }
            return view.render('devices.index', data)
        } catch(error){
            Logger.info('error %s',error)
        }
    }

    async getQR({ params,response }) {
        Logger.info('License %s',await Chatfire.checkLicense())
        if(await Chatfire.checkLicense()){
            let data = {license:false}
            return response.send("data: "+ JSON.stringify(data) +"\n\n")
        }else{
            try {
                const device = await Device.find(params.id)
                let { status, qr_code } = device
                let license = true;
                const data = {
                  status,
                  qr_code,
                  license
                }
                return response.send("data: "+ JSON.stringify(data) +"\n\n")
            } catch(error){
                return error
            }
        }
    }
}

module.exports = DeviceController