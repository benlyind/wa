'use strict'

const User = use('App/Models/User')

class UserController {
  async index({ request }) {
    const { page, limit, sort_by, order_by } = request.query
    const fields = ['id', 'email', 'role', 'created_at', 'updated_at']

    return await User
      .query()
      .orderBy(sort_by(fields), order_by)
      .paginate(page, limit)
  }

  async show({ params }) {
    return await User.findOrFail(params.id)
  }
}

module.exports = UserController
