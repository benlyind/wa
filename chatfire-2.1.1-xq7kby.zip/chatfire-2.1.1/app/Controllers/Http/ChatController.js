'use strict'

const { ChatModification } = require("@adiwajshing/baileys")

const Chatfire = use('Chatfire')
const Error = use('Error')
const Event = use('Event')
const moment = use('moment')

class ChatController {
  async index({ request }) {
    const { device_id } = request

    try {
      const wa = await Chatfire.pick(device_id)
      const chats = wa.chats.all()
      return chats.map(this.format)
    } catch (error) {
      console.log(error)
    }

    return []
  }

  async show({ params, request }) {
    const { device_id } = request

    try {
      const wa = await Chatfire.pick(device_id)
      const chat = wa.chats.get(Chatfire.jid(params.id))
      return this.format(chat)
    } catch (error) {
      throw new Error('chat/not-found')
    }
  }
  async loadMore({ request, params, response }) {
    const { device_id } = request
    const wa = await Chatfire.pick(device_id)
    if (params.cursor) {
        let chats  = await wa.loadChats(25, params.cursor)
        let data   = chats.chats.map(this.format)
        let cursor = chats.cursor
        let i      = 0;
        for (const val of data) {
          let ppUrl = 'https://www.seekpng.com/png/detail/428-4287240_no-avatar-user-circle-icon-png.png';
          try {
            ppUrl    = await wa.getProfilePicture(val.id)
            data[i].ppUrl = ppUrl;
          } catch (error) {
            data[i].ppUrl = ppUrl;
          }
          try {
            unread    = await Database.raw("select count(*) as total from messages where from_me = '0' and status != 'READ' and device_id = '"+device_id+"' and \"from\" = '"+ val.id +"';")
            if(unread.rowCount > 0){
              data[i].unread = unread.rows[0].total;
            }
          } catch (error) {
          }
          i++;
        }
        return {chat:data,cursor:cursor}
    }
  }
  async destroy({ params, request, response }) {
    const { device_id } = request

    try {
      const wa = await Chatfire.pick(device_id)
      const cleared = await wa.modifyChat(Chatfire.jid(params.id), ChatModification.delete)

      if (cleared.status !== 200) {
        throw new Error('chat/clear-failed')
      }

      Event.fire('clear::chat', { chat_id: Chatfire.rejid(params.id) })
      return response.noContent()

    } catch (error) {
      if (error.message.includes('not found')) {
        throw new Error('chat/not-found')
      } else {
        throw new Error('chat/clear-failed')
      }
    }
  }

  format({ jid, name, messages, metadata }) {
    const id = Chatfire.rejid(jid)
    const is_group = Chatfire.isGroup(jid)
    let lastMessage = [...messages.array].pop();
    let official = false;
    if(is_group && metadata){
      name  = metadata.subject
    }else{
      if(lastMessage && lastMessage.messageStubParameters.length){
        name = lastMessage.messageStubParameters[0]
        //official = true;
      }
    }
    let time = moment().format("H:mm");
    if(lastMessage){
      let last = new Date(lastMessage.messageTimestamp.low * 1000);
      time = moment(last).format("H:mm");
    }
    return {
      id,
      name: name || id,
      is_group,
      lastMessage,
      time,
      official
    }
  }
}

module.exports = ChatController
