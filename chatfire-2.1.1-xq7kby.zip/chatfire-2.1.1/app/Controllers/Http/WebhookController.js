'use strict'

const Device = use('App/Models/Device')
class WebhookController {
  async update({ params, auth, request, response }) {
    const id = params.id
    const owner_id = auth.user.id
    const { url, headers } = request.only(['url', 'headers'])
    const device = await Device.query().where({ id }).byOwner(owner_id).firstOrFail()
    const webhook = await device.webhook().fetch()

    if (webhook.url !== url) {
      webhook.url = url
    }

    if (headers && headers !== webhook.headers) {
      webhook.headers = JSON.stringify(headers)
    }

    await webhook.save()
    return webhook
  }

  async list({ params, auth, request, response }) {
    const device = request.device
    const webhook = await device.webhook().fetch()

    return await webhook
      .events()
      .orderBy('id', 'DESC')
      .fetch()
  }
}

module.exports = WebhookController
