'use strict'

const Device = use('App/Models/Device')
const Config = use('Config')
const DeviceStatus = Config.get('device.status')
const Event = use('Event')

class DeviceController {
  async index({ auth, request }) {
    const owner_id = auth.user.id
    const { page, limit, sort_by, order_by } = request.query
    const fields = ['id', 'name', 'phone', 'status', 'created_at', 'updated_at']

    return await Device
      .query()
      .byOwner(owner_id)
      .with('webhook')
      .orderBy(sort_by(fields), order_by)
      .paginate(page, limit)
  }

  async store({ auth, request }) {
    const { name } = request.all()
    const owner_id = auth.user.id
    const device = await Device.create({ name, owner_id })

    return await Device.find(device.id)
  }

  async show({ request, response }) {
    return request.device
  }

  async update({ request, response }) {
    const { name } = request.only(['name'])
    const device = request.device

    device.merge({ name })
    await device.save()

    return device
  }

  async destroy({ request, response }) {
    const device = request.device

    Event.fire('close::device', { id: device.id, reason: 'deleted' })
    return response.noContent()
  }

  async pair({ request, response, view }) {
    const { html } = request.only(['html'])
    const device = request.device
    let { status, qr_code } = device
    const messages = {
      PAIRED: 'Device was paired to your whatsapp account',
      PAIRING: 'There is a qr_code and you need to take a picture of it in your whatsapp app.',
      IDLE: 'Device is running up, please wait a moment and try again!',
      LICENSE: 'PLEASE ENTER YOUR LICENSE!'
    }

    if (status === DeviceStatus.IDLE) {
      Event.fire('connecting::device', { id: device.id, auth: device.auth })
    }

    if (status === DeviceStatus.PAIRING && qr_code === null) {
      status = DeviceStatus.IDLE
    }

    const data = {
      status,
      qr_code,
      message: messages[status]
    }

    if (html) {
      return view.render('device.pair', data)
    }

    return response.status(200).json(data)
  }

  async unpair({ request, response }) {
    const device = request.device

    if (device.status !== DeviceStatus.IDLE) {
      Event.fire('close::device', { id: device.id, reason: 'force-unpaired' })
    }

    return response.status(200).json({
      message: 'Unpairing device success'
    })
  }
}

module.exports = DeviceController
