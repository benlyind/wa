'use strict'

const Message = use('App/Models/Message')

class StoryController {
  async index({ request, response }) {
    const { device_id } = request
    const { page, limit, sort_by, order_by } = request.query
    const fields = ['id', 'from', 'type', 'read', 'created_at']

    return await Message
      .query()
      .byDevice(device_id)
      .onlyStory()
      .orderBy(sort_by(fields), order_by)
      .paginate(page, limit)
  }

  async show({ params, request, response }) {
    const { device_id } = request
    const { id } = params

    return await Message
      .query()
      .byDevice(device_id)
      .onlyStory()
      .where({ id })
      .firstOrFail()
  }
}

module.exports = StoryController
