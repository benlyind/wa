'use strict'

const User = use('App/Models/User')
const Device = use('App/Models/Device')

class UserController {
  async index({ auth, request }) {
    const { page, limit, sort_by, order_by } = request.query
    const fields = ['id', 'email', 'role', 'created_at', 'updated_at']

    return await User
      .query()
      .whereNot({ id: auth.user.id })
      .orderBy(sort_by(fields), order_by)
      .paginate(page, limit)
  }

  async show({ params }) {
    return await User.findOrFail(params.id)
  }

  async devices({ params, request }) {
    const user = await User.findOrFail(params.id)
    const { page, limit, sort_by, order_by } = request.query
    const fields = ['id', 'name', 'phone', 'status', 'created_at', 'updated_at']

    return await Device
      .query()
      .where({ owner_id: user.id })
      .orderBy(sort_by(fields), order_by)
      .paginate(page, limit)
  }
}

module.exports = UserController
