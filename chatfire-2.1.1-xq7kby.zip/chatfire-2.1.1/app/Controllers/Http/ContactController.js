'use strict'

const Contact = use('App/Models/Contact')
const Chatfire = use('Chatfire')

class ContactController {
  async index({ request, response, view }) {
    const { device_id } = request
    const { page, limit, sort_by, order_by } = request.query
    const fields = ['id', 'name', 'phone']

    return await Contact
      .query()
      .byDevice(device_id)
      .orderBy(sort_by(fields), order_by)
      .paginate(page, limit)
  }

  async show({ params, request, response, view }) {
    const { device_id } = request
    const { id } = params

    return await Contact
      .query()
      .byDevice(device_id)
      .where({ id })
      .firstOrFail()
  }

  async verify({ request, response }) {
    const { device_id } = request
    const { phone } = request.only(['phone'])
    return await Chatfire.info(device_id, phone)
  }
}

module.exports = ContactController
