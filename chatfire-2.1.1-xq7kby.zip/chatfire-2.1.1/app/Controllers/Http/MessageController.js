'use strict'

const Message = use('App/Models/Message')
const Chatfire = use('Chatfire')
const Event = use('Event')

class MessageController {
  async index({ request, response }) {
    const { device_id } = request
    const { page, limit, sort_by, order_by, chat_id } = request.query
    const fields = ['id', 'to', 'from', 'type', 'status', 'created_at', 'updated_at']

    let messages = await Message
      .query()
      .byDevice(device_id)
      .excludeStory()
      .orderBy(sort_by(fields), order_by)
      .paginate(page, limit)

    messages = messages.toJSON()
    if (chat_id) {
      messages.data = messages.data.filter(m => m[m.from_me ? 'to' : 'from'] === chat_id)
    }
    return messages
  }

  async show({ params, request, response }) {
    const { device_id } = request
    const { id } = params

    return await Message
      .query()
      .byDevice(device_id)
      .excludeStory()
      .where({ id })
      .firstOrFail()
  }

  async sendText({ request, response }) {
    const { device_id } = request
    const { to, message, reply_for } = request.only(['to', 'message', 'reply_for'])
    let quoted
    let sender_name = 'system';
    let newMessage = {
      device_id,
      to,
      message,
      type: 'text',
      from_me: true,
      from_group: Chatfire.isGroup(to),
      reply_for,
      sender_name
    }

    //if(/\p{Extended_Pictographic}/u.test(message) == false){
      newMessage = await Message.create(newMessage)
      const savedMessage = await Message.find(newMessage.id)

      if (reply_for) {
        quoted = await Message.find(reply_for)
      }
      Event.fire('send::message', { id: device_id, data: savedMessage, quoted })
      return response.send(savedMessage)
    // }else{
    //   Event.fire('send::message', { id: device_id, data: newMessage, quoted })
    // }
  }


  async sendMedia({ request, response }) {
    const { device_id } = request
    const { to, message, media_url, type, reply_for } = request.only(['to', 'message', 'media_url', 'type', 'reply_for'])
    let sender_name = 'system';
    const newMessage = await Message.create({
      device_id,
      to,
      message,
      media_url,
      type,
      from_me: true,
      from_group: Chatfire.isGroup(to),
      reply_for,
      sender_name
    })
    const savedMessage = await Message.find(newMessage.id)

    let quoted
    if (reply_for) {
      quoted = await Message.find(reply_for)
    }

    Event.fire('send::message', { id: device_id, data: savedMessage, quoted })
    return response.send(savedMessage)
  }
}

module.exports = MessageController
