'use strict'

const Setting = use('App/Models/Setting')

class SettingController {
  async show({ request }) {
    const { device_id } = request
    return await Setting
      .query()
      .byDevice(device_id)
      .firstOrFail()
  }

  async update({ request }) {
    const { device_id } = request
    const setting = await Setting
      .query()
      .byDevice(device_id)
      .firstOrFail()
    const data = request.only(Setting.visible)

    setting.merge({ ...setting.toJSON(), ...data })
    await setting.save()
    return setting
  }
}

module.exports = SettingController
