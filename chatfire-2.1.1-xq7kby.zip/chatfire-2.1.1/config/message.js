'use strict'

module.exports = {
  statuses: {
    PENDING: 'PENDING',
    SENT: 'SENT',
    RECEIVED: 'RECEIVED',
    READ: 'READ',
    PLAYED: 'PLAYED',
    FAILED: 'FAILED'
  },
  types: {
    TEXT: 'chat',
    AUDIO: 'audio',
    VOICE: 'ptt',
    IMAGE: 'image',
    VIDEO: 'video',
    DOCUMENT: 'document',
    STICKER: 'sticker',
    LOCATION: 'location',
    CONTACT_CARD: 'vcard',
    CONTACT_CARD_MULTI: 'multi_vcard',
    REVOKED: 'revoked',
    UNKNOWN: 'unknown'
  },
  events: {
    SEND: 'SEND',
    RECEIVE: 'RECEIVE'
  }
}
