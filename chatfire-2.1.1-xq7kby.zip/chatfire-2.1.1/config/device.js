module.exports = {
  status: {
    IDLE: 'IDLE',
    LOADING: 'LOADING',
    PAIRING: 'PAIRING',
    PAIRED: 'PAIRED',
    LICENSE: 'LICENSE'
  }
}
