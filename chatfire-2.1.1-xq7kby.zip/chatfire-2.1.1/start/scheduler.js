'use strict'

const Scheduler = use('Scheduler')
Scheduler.run()