'use strict'

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Http routes are entry points to your web application. You can create
| routes for different URLs and bind Controller actions to them.
|
| A complete guide on routing is available here.
| http://adonisjs.com/docs/4.1/routing
|
*/

/** @type {typeof import('@adonisjs/framework/src/Route/Manager')} */
const Route = use('Route')
Route.get('/', 'Dashboard/DashboardController.index')
Route.group(() => {
  Route.get('/', 'Dashboard/DeviceController.index')
  Route.post('/', 'Dashboard/DeviceController.store')
  Route.get('/qr/:id', 'Dashboard/DeviceController.getQR').middleware(['eventsource'])
}).prefix('devices')
Route.group(() => {
  Route.get('/', 'Dashboard/WebhooksController.index')
  Route.post('/', 'Dashboard/WebhooksController.store')
}).prefix('webhooks')
Route.group(() => {
  Route.get('/', 'Dashboard/MessageController.index')
  Route.get('/:phone', 'Dashboard/MessageController.index')
  Route.post('/', 'Dashboard/MessageController.store')
}).prefix('message')
Route.group(() => {
  Route.get('/', 'Dashboard/ScheduleController.index')
  Route.post('/', 'Dashboard/ScheduleController.store')
  Route.get('/delete/:id', 'Dashboard/ScheduleController.delete')
}).prefix('schedule')
Route.group(() => {
  Route.get('/:device_key?/:id?', 'Dashboard/ChatController.index')
  Route.post('/upload', 'Dashboard/ChatController.store')
}).prefix('chat')
Route.group(() => {
  Route.get('/:device_key?/:id?', 'Dashboard/ChatController.group')
  Route.post('/import', 'Dashboard/ContactController.import')
}).prefix('groups')
Route.group(() => {
  Route.get('/', 'Dashboard/AgentController.index')
  Route.post('/', 'Dashboard/AgentController.store')
}).prefix('agent')
Route.get('/media/:wid?', 'Dashboard/ChatController.show')
Route.get('/contacts', 'Dashboard/ContactController.index')
Route.get('/auto-replies', 'Dashboard/AutoRepliesController.index')
Route.get('/auto-replies/delete/:id', 'Dashboard/AutoRepliesController.delete')
Route.post('/auto-replies', 'Dashboard/AutoRepliesController.store')
Route.get('/login', 'Dashboard/AuthController.index').as('login.index')
Route.post('/login', 'Dashboard/AuthController.login').middleware(['guest']).validator('Login')
Route.get('/license', 'Dashboard/AuthController.license').as('login.license')
Route.post('/license', 'Dashboard/AuthController.licensing')
Route.get('logout', 'Dashboard/AuthController.logout')


Route.get('/api', () => {
  return { greeting: 'Hello world in JSON' }
})

Route.group(() => {
  Route.post('login', 'AuthController.login').middleware(['guest']).validator('Login')
  Route.get('logout', 'AuthController.logout').middleware(['guest'])
  Route.post('register', 'AuthController.register').middleware(['guest']).validator('Register')
  Route.post('refresh', 'AuthController.refresh').middleware(['guest']).validator('RefreshToken')
  Route.get('me', 'AuthController.me').middleware(['auth'])
}).prefix('api/auth')

Route.group(() => {
  Route.get('/', 'DeviceController.index')
  Route.post('/', 'DeviceController.store').validator('StoreDevice')
  Route.get('/:id', 'DeviceController.show').middleware('own_device')
  Route.patch('/:id', 'DeviceController.update').middleware('own_device').validator('StoreDevice')
  Route.delete('/:id', 'DeviceController.destroy').middleware('own_device')
  Route.get('/:id/pair', 'DeviceController.pair').middleware(['own_device', 'device_must_have_whatsapp'])
  Route.get('/:id/unpair', 'DeviceController.unpair').middleware('own_device')
  Route.post('/:id/set-webhook', 'WebhookController.update').middleware('own_device')
  Route.get('/:id/events', 'WebhookController.list').middleware('own_device')
}).prefix('api/devices').middleware(['auth'])

Route.group(() => {
  Route.get('/', 'MessageController.index')
  Route.get('/:id', 'MessageController.show')
  Route.post('/send-text', 'MessageController.sendText').validator('SendText')
  Route.get('/send/text', 'MessageController.sendText').validator('SendText')
  Route.get('/send/media', 'MessageController.sendMedia').validator('SendMedia')
  Route.post('/send-media', 'MessageController.sendMedia').validator('SendMedia')
}).prefix('api/messages').middleware(['device_key'])

Route.group(() => {
  Route.get('/', 'GroupController.index')
  Route.get('/:id', 'GroupController.show')
}).prefix('api/groups').middleware(['device_key'])

Route.group(() => {
  Route.get('/', 'ContactController.index')
  Route.get('/:id', 'ContactController.show')
  Route.post('/verify', 'ContactController.verify').validator('Phone').middleware('device_must_have_whatsapp')
}).prefix('api/contacts').middleware(['device_key'])

Route.group(() => {
  Route.get('/', 'StoryController.index')
  Route.get('/:id', 'StoryController.show')
}).prefix('api/stories').middleware(['device_key'])

Route.group(() => {
  Route.get('/', 'UserController.index')
  Route.get('/:id', 'UserController.show')
}).prefix('api/users').middleware(['auth', 'is_admin'])

Route.group(() => {
  Route.get('/', 'SettingController.show')
  Route.patch('/', 'SettingController.update')
}).prefix('api/setting').middleware(['device_key'])

Route.group(() => {
  Route.get('/', 'ChatController.index')
  Route.get('/:id', 'ChatController.show')
  Route.delete('/:id', 'ChatController.destroy')
  Route.get('/more/:cursor', 'ChatController.loadMore')
}).prefix('api/chats').middleware(['device_key', 'device_must_be_paired'])

Route.group(() => {
  Route.get('/users', 'Admin/UserController.index')
  Route.get('/users/:id', 'Admin/UserController.show')
  Route.get('/users/:id/devices', 'Admin/UserController.devices')
}).prefix('api/admin').middleware(['auth', 'is_admin'])
