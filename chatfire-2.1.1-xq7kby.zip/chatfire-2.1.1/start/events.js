'use strict'

const Event = use('Event')

Event.when('open::device', 'Device.open')
Event.when('connecting::device', 'Device.connecting')
Event.when('close::device', 'Device.close')
Event.when('qr::device', 'Device.qr')
Event.when('battery::device', 'Device.battery')
Event.when('session-change::device', 'Device.session_change')
Event.when('state-change::device', 'Device.state_change')
Event.when('reconnect::device', 'Device.reconnect')

Event.when('sync::chat', 'Chat.sync')
Event.when('clear::chat', 'Chat.clear')

Event.when('new::message', 'Message.receive')
Event.when('send::message', 'Message.send')
Event.when('status::message', 'Message.status')
Event.when('unread::message', 'Message.unread')

Event.when('sync::group', 'Group.sync')
Event.when('update::group', 'Group.update')

Event.when('sync::contact', 'Contact.sync')
Event.when('status::contact', 'Contact.status')

Event.when('sync::story', 'Story.sync')

Event.when('voice::missed-call', 'MissedCall.voice')
Event.when('video::missed-call', 'MissedCall.video')

Event.when('license::failed', 'Device.failed')