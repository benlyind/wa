'use strict'

const { hooks } = require('@adonisjs/ignitor')

hooks.before.httpServer(async () => {
  const Device = use('App/Models/Device')
  const Chatfire = use('Chatfire')

  await Device
    .query()
    .whereNot('status', 'IDLE')
    .update({ status: 'IDLE', qr_code: null })

  const pairedDevices = await Device
    .query()
    .whereNot('auth', null)
    .fetch()

  const { rows: devices } = pairedDevices
  if (devices.length <= 0) return

  console.log(`Re-Connecting ${devices.length} device to whatsapp...`)
  devices.map(async (device) => {
    Chatfire.init(device.id)
    Chatfire.login(device.id, device.auth)
  })
})

hooks.after.providersBooted(() => {
    const Env = use('Env')
    const View = use('View')

    View.global('APP_URL', function () {
        return Env.get('APP_URL')
    })
})