'use strict'

const { ServiceProvider } = require('@adonisjs/fold')
const { Chatfire } = require('./lib')

class ChatfireProvider extends ServiceProvider {
  /**
   * Register namespaces to the IoC container
   *
   * @method register
   *
   * @return {void}
   */
  register() {
    this.app.singleton('Chatfire', (app) => {
      const Event = app.use('Event')
      const Config = app.use('Config')
      const app_name = Config.get('app.name')
      const version = Config.get('app.version')
      const env = Config.get('app.node_env')
      return new Chatfire(Event, { app_name, version, env })
    })
  }
  

  /**
   * Attach context getter when all providers have
   * been registered
   *
   * @method boot
   *
   * @return {void}
   */
  boot() {
    //
  }
}

module.exports = ChatfireProvider
