'use strict'

const got = require('got')

class Notification {
  constructor(headers, Webhook) {
    this.headers = headers || {}
    this.Webhook = Webhook
  }

  async send(id, payload) {
    const webhook = await this.Webhook.findBy('device_id', id)
    if (!webhook || !webhook.url) return

    try {
      await got.post(webhook.url, {
        headers: { ...this.headers, ...webhook.headers },
        json: {
          device_id: id,
          ...payload
        }
      })
    } catch (error) {
      console.log(`[device::${id}] Webhook Notification send failed cause : ${error.message}`)
    }
  }
}

module.exports = Notification
