'use strict'

const { ServiceProvider } = require('@adonisjs/fold')
const Notification = require('./index')

class NotificationProvider extends ServiceProvider {
  /**
   * Register namespaces to the IoC container
   *
   * @method register
   *
   * @return {void}
   */
  register() {
    this.app.singleton('Notification', (app) => {
      const Config = app.use('Config')
      const { name, version } = Config.get('app')
      const Webhook = app.use('App/Models/Webhook')

      return new Notification({
        'User-Agent': `${name}/${version}`,
        'X-Powered-By': 'Chatfire App'
      }, Webhook)
    })
  }

  /**
   * Attach context getter when all providers have
   * been registered
   *
   * @method boot
   *
   * @return {void}
   */
  boot() {
    //
  }
}

module.exports = NotificationProvider
