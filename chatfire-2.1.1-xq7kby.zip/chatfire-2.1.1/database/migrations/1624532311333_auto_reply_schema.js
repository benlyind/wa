'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class AutoReplySchema extends Schema {
  up () {
    this.create('auto_replies', (table) => {
      table.increments()
      table.integer('device_id').unsigned().references('id').inTable('devices').onDelete('CASCADE')
      // body
      table.text('keyword')
      table.text('message')
      // footer
      table.string('status', 10).defaultTo('ACTIVE')
      table.timestamps()
    })
  }

  down () {
    this.drop('auto_replies')
  }
}

module.exports = AutoReplySchema
