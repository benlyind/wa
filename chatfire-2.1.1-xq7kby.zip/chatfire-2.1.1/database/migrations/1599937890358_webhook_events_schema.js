'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class WebhookEventsSchema extends Schema {
  up() {
    this.create('webhook_events', (table) => {
      table.increments()
      table.integer('webhook_id').unsigned().references('id').inTable('webhooks').onDelete('CASCADE')
      table.string('event')
      table.json('data')
      table.boolean('processed').defaultTo(false)
      table.integer('code')
      table.string('message')
      table.timestamps()
    })
  }

  down() {
    this.drop('webhook_events')
  }
}

module.exports = WebhookEventsSchema
