'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class AlterDevicesSchema extends Schema {
  up() {
    this.alter('devices', (table) => {
      table.string('os_version', 25).alter()
    })
  }

  down() { }
}

module.exports = AlterDevicesSchema
