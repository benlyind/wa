'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class AlterSchedulesSchema extends Schema {
  up () {
    this.table('schedules', (table) => {
      // alter table
      table.integer( 'message_id' ).nullable();
    })
  }

  down () {
    this.table('schedules', (table) => {
      // reverse alternations
      table.dropColumn( 'message_id' );
    })
  }
}

module.exports = AlterSchedulesSchema
