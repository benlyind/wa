'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class GroupsSchema extends Schema {
  up() {
    this.create('groups', (table) => {
      table.string('id').primary()
      table.integer('device_id').unsigned().references('id').inTable('devices').onDelete('CASCADE')
      table.string('name')
      table.string('owner')
      table.json('participants')
      table.timestamps()
    })
  }

  down() {
    this.drop('groups')
  }
}

module.exports = GroupsSchema
