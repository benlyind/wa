'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class TagDetailsSchema extends Schema {
  up () {
    this.create('tag_details', (table) => {
      table.increments()
      table.integer('tag_id').unsigned().references('id').inTable('tags').onDelete('CASCADE')
      table.integer('contact_id').unsigned().references('id').inTable('contacts').onDelete('CASCADE')
      table.timestamps()
    })
  }

  down () {
    this.drop('tag_details')
  }
}

module.exports = TagDetailsSchema
