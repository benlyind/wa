'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class UsersSchema extends Schema {
  up () {
    this.raw(`alter table "users"
    DROP CONSTRAINT "users_role_check",
    ADD CONSTRAINT "users_role_check" 
    check ("role" in ('admin', 'member', 'agent'))`);  
  }

  down () {
    this.alter('users', (table) => {
      this.raw(`alter table "users"
      DROP CONSTRAINT "users_role_check",
      ADD CONSTRAINT "users_role_check" 
      check ("role" in ('admin', 'member'))`);  
    })
  }
}

module.exports = UsersSchema
