'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class AlterContactsSchema extends Schema {
  up () {
    this.table('contacts', (table) => {
      table.string('ppUrl')
      table.string('status')
    })
  }

  down () {
    this.table('contacts', (table) => {
      table.dropColumn('ppUrl')
      table.dropColumn('status')
    })
  }
}

module.exports = AlterContactsSchema
