'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class ScheduleSchema extends Schema {
  up () {
    this.create('schedules', (table) => {
      table.increments()
      table.integer('device_id').unsigned().references('id').inTable('devices').onDelete('CASCADE')
      // body
      table.text('time')
      table.text('phone')
      table.text('message')
      // footer
      table.string('status', 10).defaultTo('ACTIVE')
      table.timestamps()
    })
  }

  down () {
    this.drop('schedules')
  }
}

module.exports = ScheduleSchema
