'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class MessagesSchema extends Schema {
  up() {
    this.create('messages', (table) => {
      table.increments()
      table.integer('device_id').unsigned().references('id').inTable('devices').onDelete('CASCADE')
      // header
      table.string('wa_id')
      table.string('to', 50)
      table.string('from', 50)
      table.boolean('from_group').defaultTo(false)
      table.boolean('from_me').defaultTo(false)
      table.boolean('from_story').defaultTo(false)
      // body
      table.text('message')
      table.string('media_url')
      // footer
      table.string('type', 10)
      table.string('status', 10).defaultTo('PENDING')
      table.timestamps()
    })
  }

  down() {
    this.drop('messages')
  }
}

module.exports = MessagesSchema
