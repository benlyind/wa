'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class WebhooksSchema extends Schema {
  up() {
    this.create('webhooks', (table) => {
      table.increments()
      table.integer('device_id').unsigned().references('id').inTable('devices').onDelete('CASCADE')
      table.string('url')
      table.json('headers')
      table.timestamps()
    })
  }

  down() {
    this.drop('webhooks')
  }
}

module.exports = WebhooksSchema
