'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')
const Database = use('Database')

class SettingsSchema extends Schema {
  up() {
    this.create('settings', (table) => {
      table.increments()
      table.integer('device_id').unsigned().references('id').inTable('devices').onDelete('CASCADE')
      table.boolean('auto_read').defaultTo(true)
      table.boolean('auto_save_media').defaultTo(true)
      table.boolean('include_group_message').defaultTo(true)
      table.boolean('sync_story').defaultTo(true)
      table.boolean('sync_contact').defaultTo(true)
      table.boolean('auto_takeover').defaultTo(true)
      table.integer('auto_takeover_delay').defaultTo(0)
      table.timestamps()
    })

    this.schedule(async (trx) => {
      let devices = await Database.from('devices').whereNotExists(function () {
        this.from('settings').whereRaw('devices.id = settings.id')
      }).transacting(trx)
      devices = devices.map(d => ({
        device_id: d.id,
        created_at: this.fn.now(),
        updated_at: this.fn.now()
      }))
      await Database.table('settings').insert(devices).transacting(trx)
    })
  }

  down() {
    this.drop('settings')
  }
}

module.exports = SettingsSchema
