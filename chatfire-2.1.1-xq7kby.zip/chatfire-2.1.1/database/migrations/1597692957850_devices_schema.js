'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')
const Config = use('Config')
const status = Config.get('device.status')

class DevicesSchema extends Schema {
  up() {
    this.create('devices', (table) => {
      table.increments()
      table.uuid('device_key').unique()
      table.integer('owner_id').unsigned().references('id').inTable('users').onDelete('CASCADE')
      table.string('name', 25).notNullable()
      table.string('phone', 15)
      table.enu('status', Object.keys(status)).defaultTo(status.IDLE)
      table.json('auth')
      table.text('qr_code')
      table.string('wa_name', 25)
      table.string('wa_version', 25)
      table.string('manufacture', 25)
      table.string('os_version', 5)
      table.integer('battery').defaultTo(0)
      table.timestamps()
    })
  }

  down() {
    this.drop('devices')
  }
}

module.exports = DevicesSchema
