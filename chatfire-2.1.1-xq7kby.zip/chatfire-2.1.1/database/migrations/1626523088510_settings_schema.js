'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class SettingsSchema extends Schema {
  up () {
    this.table('settings', (table) => {
       table.text('license').nullable()
    })
  }

  down () {
    this.table('settings', (table) => {
      // reverse alternations
      table.dropColumn( 'license' );
    })
  }
}

module.exports = SettingsSchema
