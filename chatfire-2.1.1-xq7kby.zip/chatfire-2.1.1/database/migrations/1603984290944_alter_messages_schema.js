'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class AlterMessagesSchema extends Schema {
  up() {
    this.table('messages', (table) => {
      table.integer('reply_for').unsigned().nullable()
      table.string('failed_reason')
      table.string('timestamp')
    })
  }

  down() {
    this.table('messages', (table) => {
      table.dropColumn('reply_for')
      table.dropColumn('failed_reason')
      table.dropColumn('timestamp')
    })
  }
}

module.exports = AlterMessagesSchema
